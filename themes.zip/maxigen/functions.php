<?php
require_once( trailingslashit( get_template_directory() ) . 'include/common.php' );
require_once( trailingslashit( get_template_directory() ) . 'include/inc.php' );
require_once( trailingslashit( get_template_directory() ) . 'admin/inc.php' );

/* ************************************************************************ */

if( !function_exists('maxigen_options') ) :

	function maxigen_options( $option, $arr = null ) {

		global $maxigen_option;

		if( $arr ) {

			if( isset( $maxigen_option[$option][$arr] ) ) {
				return $maxigen_option[$option][$arr];
			}
		}
		else {
			if( isset( $maxigen_option[$option] ) ) {
				return $maxigen_option[$option];
			}
		}
	}
endif;

/* ************************************************************************ */

/**
 * Filters all menu item URLs for a #placeholder#.
 *
 * @param WP_Post[] $menu_items All of the nave menu items, sorted for display.
 *
 * @return WP_Post[] The menu items with any placeholders properly filled in.
 */
function maxigen_dynamic_menu_items( $menu_items ) {

    foreach ( $menu_items as $menu_item ) {

		$url = substr( $menu_item->url, 0, 1);

        if ( '#' === $url && !is_front_page() ) {
			$menu_item->url = trailingslashit( home_url() ) . $menu_item->url;
        }
    }

    return $menu_items;
}
add_filter( 'wp_nav_menu_objects', 'maxigen_dynamic_menu_items' );

/* ************************************************************************ */

/**
 * Set up the content width value based on the theme's design.
 *
 * @see maxigen_content_width()
 *
 * @since Maxigen 1.0
 */
if ( ! isset( $content_width ) ) { $content_width = 474; }

/**
 * Adjust content_width value for image attachment template.
 *
 * @since Maxigen 1.0
 */
if( !function_exists('maxigen_content_width') ) :
	function maxigen_content_width() {
		if ( is_attachment() && wp_attachment_is_image() ) { $GLOBALS['content_width'] = 810; }
	}
	add_action( 'template_redirect', 'maxigen_content_width' );
endif;

/* ************************************************************************ */

/**
 * Theme setup.
 *
 * Set up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support post thumbnails.
 *
 * @since Maxigen 1.0
 */
if( !function_exists('maxigen_theme_setup') ) :

	function maxigen_theme_setup() {

		/* load theme languages */
		load_theme_textdomain( "maxigen", get_template_directory() . '/languages' );
	
		/* Image Sizes */
		set_post_thumbnail_size( 810, 320, true ); /* Default Featured Image */

		add_image_size( 'maxigen-810-320', 810, 320, true ); /* Single Blog Post  Gallery */
		add_image_size( 'maxigen-1170-450', 1170, 450, true ); /* Single Gallery */
		add_image_size( 'maxigen-270-250', 270, 250, true ); /* Single Gallery List */

		// This theme uses wp_nav_menu() in two locations.
		register_nav_menus( array(
			'ng_primary_nav'   => esc_html__( 'Primary menu', "maxigen" ),
			'ng_secondary_nav'   => esc_html__( 'Footer menu', "maxigen" ),
		) );

		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );

		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

		/*
		 * Enable support for Post Formats.
		 *
		 * See: https://codex.wordpress.org/Post_Formats
		 */
		add_theme_support( 'post-formats', array( 'video', 'gallery', 'audio' ) );
	}
	add_action( 'after_setup_theme', 'maxigen_theme_setup' );
endif;


/* ************************************************************************ */

if ( ! function_exists( 'maxigen_to_slug' ) ) :
	function maxigen_to_slug( $string ){
		return strtolower( trim( preg_replace('/[^A-Za-z0-9-]+/', '_', $string) ) );
	}
endif;

/* ************************************************************************ */

/**
 * Enqueue scripts and styles for the front end.
 *
 * @since Maxigen 1.0
 */
if( !function_exists('maxigen_enqueue_scripts') ) :

	function maxigen_enqueue_scripts() {

		// load the Internet Explorer specific stylesheet.
		wp_enqueue_style( 'ie-css', get_template_directory_uri() . '/css/ie.css' , '20131205' );
		wp_style_add_data( 'ie-css', 'conditional', 'lt IE 9' );

		// Load the html5 shiv.
		wp_enqueue_script( 'respond-min', get_template_directory_uri() . '/js/html5/respond.min.js', array(), '3.7.3' );
		wp_script_add_data( 'respond-min', 'conditional', 'lt IE 9' );

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		/* Font Icons */
		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'maxigen-lib', get_template_directory_uri() . '/libraries/lib.css');
		wp_enqueue_style( 'maxigen-plugins', get_template_directory_uri() . '/css/plugins.css');
		wp_enqueue_style( 'maxigen-navigation-menu', get_template_directory_uri() . '/css/navigation-menu.css');

		/* Custom Stylesheet */
		wp_enqueue_style( 'maxigen-stylesheet', get_template_directory_uri() . '/style.css' );
		wp_enqueue_style( 'maxigen-shortcodes', get_template_directory_uri() . '/css/shortcodes.css');

		/* Functions JS */		
		wp_enqueue_script( 'maxigen-lib', get_template_directory_uri() . '/libraries/lib.js', array( 'jquery' ),  null, true );
		wp_enqueue_script( 'maxigen-functions', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ),  null, true );

	}
	add_action( 'wp_enqueue_scripts', 'maxigen_enqueue_scripts' );
endif;

/* ************************************************************************ */

/**
 * Extend the default WordPress body classes.
 *
 * @since Maxigen 1.0
 *
 * @param array $classes A list of existing body class values.
 * @return array The filtered body class list.
 */
if( !function_exists('maxigen_body_classes') ) :

	function maxigen_body_classes( $classes ) {

		if ( is_singular() && ! is_front_page() ) {
			$classes[] = 'singular';
		}

		if( is_front_page() && !is_home() ) {
			$classes[] = 'front-page';
		}

		return $classes;
	}
	add_filter( 'body_class', 'maxigen_body_classes' );
endif;

/**
 * Extend the default WordPress post classes.
 *
 * Adds a post class to denote:
 * Non-password protected page with a post thumbnail.
 *
 * @since Maxigen 1.0
 *
 * @param array $classes A list of existing post class values.
 * @return array The filtered post class list.
 */
if( !function_exists('maxigen_post_classes') ) :
	function maxigen_post_classes( $classes ) {
		if ( ! is_attachment() && has_post_thumbnail() ) { $classes[] = 'has-post-thumbnail'; }
		return $classes;
	}
	add_filter( 'post_class', 'maxigen_post_classes' );
endif;

/* ************************************************************************ */

/**
 * Add a `screen-reader-text` class to the search form's submit button.
 *
 * @since Maxigen 1.0
 *
 * @param string $html Search form HTML.
 * @return string Modified search form HTML.
 */
function maxigen_search_form_modify( $html ) {
	$html = '<form method="get" id="searchform" class="searchform" action="' . home_url( '/' ) . '" >
	<div class="input-group">
	<input type="text" name="s" id="s" placeholder="Search" class="form-control" required>
	<span class="input-group-btn">
		<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
	</span>
	</div><!-- /input-group -->
	</form>';
	return $html;
}
add_filter( 'get_search_form', 'maxigen_search_form_modify' );

// Register Owl Carousel Scripts and Styles
function enqueue_owl_carousel_assets() {
    wp_enqueue_style('owl-carousel-css', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css');
    wp_enqueue_style('owl-theme-css', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css');
    wp_enqueue_script('owl-carousel-js', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_owl_carousel_assets');

// Shortcode for Owl Carousel
function gs_logo_slider_shortcode() {
    // Fetch posts from gs-logo-slider
    $args = array(
        'post_type'      => 'gs-logo-slider',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
    );
    $query = new WP_Query($args);

    if ($query->have_posts()) {
        $output = '<div class="owl-carousel gs-logo-slider">';
        while ($query->have_posts()) {
            $query->the_post();
            $logo_url = get_post_meta(get_the_ID(), 'gs_logo_slider_url_field', true);
            $logo_image = get_the_post_thumbnail_url(get_the_ID(), 'full');

            if ($logo_image) {
                $output .= '<div class="logo-item">';
                if ($logo_url) {
                    $output .= '<a href="' . esc_url($logo_url) . '" target="_blank"><img src="' . esc_url($logo_image) . '" alt="' . esc_attr(get_the_title()) . '"></a>';
                } else {
                    $output .= '<img src="' . esc_url($logo_image) . '" alt="' . esc_attr(get_the_title()) . '">';
                }
                $output .= '</div>';
            }
        }
        wp_reset_postdata();
        $output .= '</div>';
        
        // Owl Carousel Initialization Script
        $output .= '
        <script>
        jQuery(document).ready(function($) {
            $(".gs-logo-slider").owlCarousel({
                items: 4,
                autoplay: true,
                autoplayTimeout: 3000,
                loop: true,
                margin: 10,
                responsive: {
                    0: { items: 1 },
                    600: { items: 2 },
                    1000: { items: 6 }
                }
            });
        });
        </script>';

        return $output;
    } else {
        return '<p>No logos found.</p>';
    }
}
add_shortcode('gs_logo', 'gs_logo_slider_shortcode');
