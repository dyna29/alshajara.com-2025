<?php

/* Define Constants */
define( 'THEME_OPTIONS', get_template_directory_uri() . '/admin/theme-options' );
define( 'ADMIN_URI', get_template_directory_uri() . '/admin' );
define( 'THEME_URI', get_template_directory_uri() );
define( 'IMG_URI', get_template_directory_uri() . '/images' );

/**
 * Register three widget areas.
 *
 * @since Maxigen 1.0
 */
if ( ! function_exists( 'maxigen_widgets_init' ) ) {
	function maxigen_widgets_init() {
		register_sidebar( array(
			'name'          => esc_html__( 'Right Sidebar', "maxigen" ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Appears in the Content section of the site.', "maxigen" ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
		));
		register_sidebar( array(
			'name'          => esc_html__( 'Left Sidebar', "maxigen" ),
			'id'            => 'sidebar-2',
			'description'   => esc_html__( 'Appears in the Content section of the site.', "maxigen" ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
		));
		register_sidebar( array(
			'name'          => esc_html__( 'Footer Widget Area 1', "maxigen" ),
			'id'            => 'sidebar-3',
			'description'   => esc_html__( 'Appears in the Content section of the site.', "maxigen" ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3>',
			'after_title'   => '</h3>',
		));
		register_sidebar( array(
			'name'          => esc_html__( 'Footer Widget Area 2', "maxigen" ),
			'id'            => 'sidebar-4',
			'description'   => esc_html__( 'Appears in the Content section of the site.', "maxigen" ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3>',
			'after_title'   => '</h3>',
		));
		register_sidebar( array(
			'name'          => esc_html__( 'Footer Widget Area 3', "maxigen" ),
			'id'            => 'sidebar-5',
			'description'   => esc_html__( 'Appears in the Content section of the site.', "maxigen" ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3>',
			'after_title'   => '</h3>',
		));
		register_sidebar( array(
			'name'          => esc_html__( 'Footer Widget Area 4', "maxigen" ),
			'id'            => 'sidebar-6',
			'description'   => esc_html__( 'Appears in the Content section of the site.', "maxigen" ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3>',
			'after_title'   => '</h3>',
		));
	}
	add_action( 'widgets_init', 'maxigen_widgets_init' );
}

/* Custom Excerpt Limit */
if ( ! function_exists( 'maxigen_custom_excerpts' ) ) :
	function maxigen_custom_excerpts( $limit ) {
		$excerpt = explode(' ', get_the_excerpt(), $limit);
		if ( count($excerpt) >= $limit ) :
		
			array_pop($excerpt);
			$excerpt = implode(" ",$excerpt).'...';
		
		else :
		
			$excerpt = implode(" ",$excerpt);
		
		endif; 

		$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
		return $excerpt;
	}
endif;

/* Custom Length Limit */
if ( ! function_exists( 'maxigen_custom_length' ) ) :
	function maxigen_custom_length( $value, $limit ) {
		$excerpt = explode(' ', $value, $limit);
		if ( count($excerpt) >= $limit ) :
		
			array_pop($excerpt);
			$excerpt = implode(" ",$excerpt).'...';
		
		else :
		
			$excerpt = implode(" ",$excerpt);
		
		endif; 

		$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
		return $excerpt;
	}
endif;	

/* Check string for Null or Empty & Print It */
if ( ! function_exists( 'maxigen_content' ) ) :

	function maxigen_content( $before_val, $after_val, $val ) {

		if( $val != "" ) {
			return $before_val.$val.$after_val;
		}
		else {
			return "";
		}
	}
endif;

/* Check array element for Null or Empty */
if ( ! function_exists( 'maxigen_checkarray' ) ) :
	function maxigen_checkarray( $arrOptions, $strKey ) {

		if( is_array( $arrOptions )
			&& array_key_exists( $strKey, $arrOptions ) 
			&& isset( $arrOptions[$strKey] ) 
			//&& trim( $arrOptions[$strKey] ) != '' 
		) {
			return true;
		} 
		
		return false;
	}
endif;

/* Check string for Null or Empty */
if ( ! function_exists( 'maxigen_checkstring' ) ) :
	function maxigen_checkstring( $strValue ) {
		if ( isset( $strValue ) && trim( $strValue ) != '' ) :
			return true;
		endif;
		
		return false;
	}
endif;
?>