<?php
require_once( trailingslashit( get_template_directory() ) . 'include/customizer.php' );
require_once( trailingslashit( get_template_directory() ) . 'include/postlike/postlike.php' );
require_once( trailingslashit( get_template_directory() ) . 'include/nav_walker.php' );
require_once( trailingslashit( get_template_directory() ) . 'include/page_walker.php' );