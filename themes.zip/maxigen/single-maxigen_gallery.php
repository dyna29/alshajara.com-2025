<?php
/**
* The Template for displaying all single posts
*
* @package WordPress
* @subpackage Maxigen
* @since Maxigen 1.0
*/
get_header();
?>
	<main id="main" class="site-main">
		<div id="en-content">
			<div class="container">
				<div id="singlegallerypost" class="row">
					<?php
					// Start the loop.
					while ( have_posts() ) : the_post();

						// Include the page content template.
						get_template_part( 'content', 'maxigen_gallery' );

					// End the loop.
					endwhile;
					?>
				</div>
			</div><!-- /.container -->
		</div>
	</main><!-- .site-main -->
<?php get_footer(); ?>