<?php
/**
* The Template for displaying all single posts
*
* @package WordPress
* @subpackage Maxigen
* @since Maxigen 1.0
*/
get_header(); ?>

<main id="main" class="site-main">
	<div class="error-page container-fluid no-padding">
		<div class="section-padding"></div>
		<!-- Container -->
		<div class="container">
			<div class="col-md-6 col-sm-6">
				<div class="error-content">
					<h5>
						<span><?php esc_html_e('Sorry,', "maxigen"); ?></span>
						<?php esc_html_e('The Page Not Found', "maxigen"); ?>
					</h5>
					<p><?php esc_html_e('Make all our dreams come true for me and you. Love exciting and new. Come aboard were expecting you. Love life s sweetest reward Let it flow it floats back to you their house.', "maxigen"); ?></p>
					<h3><?php esc_html_e('404', "maxigen"); ?></h3>
				</div>
				<?php get_search_form(); ?>
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="error-image">
					<img src="<?php echo esc_url( IMG_URI ); ?>/404.png" alt="404">
				</div>
			</div>
		</div><!-- Container /- -->
		<div class="section-padding"></div>
	</div>
</main><!-- .site-main -->

<?php get_footer(); ?>