<?php
/* Footer Settings */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Footer Settings', "maxigen" ),
	'icon' => 'el el-wrench-alt',
	'subsection' => false,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_footer_copyright',
			'type'     => 'editor',
			'title'    => esc_html__( 'Copyright Text', "maxigen" ),
			'subtitle' => esc_html__( 'Use any of the features of WordPress editor inside your panel!', "maxigen" ),
			'default'  => '&copy; 2017 All Rights Reserved',
		),
		/* Fields /- */	
	),
));
?>