<?php
/* Header Settings */
Redux::setSection( $opt_name, array(
	'title'  => esc_html( 'Header', "maxigen" ),
	'id'    => 'header_settings',
	'icon'  => 'el el-credit-card',
	'subsection' => false,
	'fields'     => array(
		/* Fields */
		
		/* Site Logo */
		array(
			'id'=>'info_logo',
			'type' => 'info',
			'title' => 'Logo',
		),
		array(
			'id'       => 'opt_logo_select',
			'type'     => 'select',
			'title'    => esc_html( 'Logo Type', "maxigen" ),
			'options'  => array(
				'1' => 'Text Logo',
				'2' => 'Image Logo',
			),
			'default'  => '2',
		),
		array(
			'id'=>'opt_site_logo',
			'type' => 'media',
			'title' => esc_html('Logo Upload', "maxigen" ),
			'required' => array( 'opt_logo_select', '=', '2' ),
			'default' => array( 'url' => esc_url( IMG_URI ) . '/logo.png' ),
		),
		
		
		/* Site Logo */
		array(
			'id'=>'info_logosecond',
			'type' => 'info',
			'title' => 'Logo For Navbar Fix-To-Top',
		),
		array(
			'id'       => 'opt_logo_selectsecond',
			'type'     => 'text',
			'title'    => esc_html( 'Text Logo', "maxigen" ),
			'default'  => esc_html('Maxigen', "maxigen")
		),
		
		/* Fields /- */
	)
) );
/* Header Settings /- */
?>