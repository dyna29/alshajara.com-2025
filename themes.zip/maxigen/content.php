<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Maxigen
 * @since Maxigen 1.0
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
		<span class="sticky-post"><?php esc_html_e( 'Featured', "maxigen" ); ?></span>
	<?php endif; ?>
	
	<?php
	// Get post format
	$post_format = get_post_format();

	/* Post Format : Gallery */
	if( $post_format == "gallery" && count( get_post_meta( get_the_ID(), 'maxigen_cf_post_gallery', 1 ) ) > 0 && is_array( get_post_meta( get_the_ID(), 'maxigen_cf_post_gallery', 1 ) ) ) {
		?>
		<div class="entry-cover">

			<!-- Carousel -->
			<div id="blog-carousel-<?php echo the_ID(); ?>" class="carousel slide" data-ride="carousel">
				<div class="carousel-inner" role="listbox">
					<?php
					$active=1;
					foreach ( (array) get_post_meta( get_the_ID(), 'maxigen_cf_post_gallery', 1 ) as $attachment_id => $attachment_url ) {
						?>
						<div class="item<?php if( $active == 1 ) { echo ' active'; } ?>">
							<?php echo wp_get_attachment_image( $attachment_id, 'maxigen-810-320' ); ?>
						</div>
						<?php
						$active++;
					} ?>
				</div>
				<a title="Previous" class="left carousel-control" href="#blog-carousel-<?php echo the_ID(); ?>" role="button" data-slide="prev">
					<span class="fa fa-chevron-left" aria-hidden="true"></span>
				</a>
				<a title="Next" class="right carousel-control" href="#blog-carousel-<?php echo the_ID(); ?>" role="button" data-slide="next">
					<span class="fa fa-chevron-right" aria-hidden="true"></span>
				</a>
			</div><!-- /.carousel -->

		</div>
		<?php
	}

	/* Post Format : Video */
	if( $post_format == "video" ) {

		if( get_post_meta( get_the_ID(), 'maxigen_cf_post_video_source', 1 ) == "video_link" && maxigen_checkstring( get_post_meta( get_the_ID(), 'maxigen_cf_post_video_link', 1 ) ) ) {
			echo wp_oembed_get( esc_url( get_post_meta( get_the_ID(), 'maxigen_cf_post_video_link', true ) ) );
		}
		elseif( get_post_meta( get_the_ID(), 'maxigen_cf_post_video_source', 1 ) == "video_embed_code" && maxigen_checkstring( get_post_meta( get_the_ID(), 'maxigen_cf_post_video_embed', 1 ) ) ) {
			echo get_post_meta( get_the_ID(), 'maxigen_cf_post_video_embed', 1 );
		}
		elseif( get_post_meta( get_the_ID(), 'maxigen_cf_post_video_source', 1 ) == "video_upload_local" && maxigen_checkstring( get_post_meta( get_the_ID(), 'maxigen_cf_post_video_local', 1 ) ) ) {
			?>
			<video controls>
				<source src="<?php echo esc_url( get_post_meta( get_the_ID(), 'maxigen_cf_post_video_local', 1 ) ); ?>" type="video/mp4">
				<?php esc_html_e("Your browser does not support the video tag.","maxigen"); ?>
			</video> 
			<?php			
		}
	}

	/* Post Format : Audio */
	if( $post_format == "audio" ) {

		if( get_post_meta( get_the_ID(), 'maxigen_cf_post_audio_source', 1 ) == "soundcloud_link" && maxigen_checkstring( get_post_meta( get_the_ID(), 'maxigen_cf_post_soundcloud_url', 1 ) ) ) {
			?>
			<iframe src="<?php echo esc_url( get_post_meta( get_the_ID(), 'maxigen_cf_post_soundcloud_url', 1 ) ); ?>"></iframe>
			<?php
		}
		elseif( get_post_meta( get_the_ID(), 'maxigen_cf_post_audio_source', 1 ) == "audio_upload_local" && maxigen_checkstring( get_post_meta( get_the_ID(), 'maxigen_cf_post_audio_local', 1 ) ) ) {
			?>
			<audio controls>
				<source src="<?php echo esc_url( get_post_meta( get_the_ID(), 'maxigen_cf_post_audio_local', 1 ) ); ?>" type="audio/mpeg">
				<?php esc_html_e("Your browser does not support the audio element.","maxigen"); ?>
			</audio>
			<?php
		}
	}

	if( has_post_thumbnail() && ( $post_format != "audio" && $post_format != "video" && $post_format != "gallery" ) ) {
		?>
		<div class="blog-list-content">
			<div class="entry-cover">
				<a href="<?php echo esc_url( get_permalink() ); ?>">
					<?php the_post_thumbnail(); ?>
				</a>
				<div class="triangle-shape" id="triangle-<?php the_ID(); ?>">
					<svg height="100" width="100">
						<clipPath clipPathUnits="objectBoundingBox" id="triangle_shape-<?php the_ID(); ?>">
							<polygon points="1 0, 0 1, 1 1, 1 0"/>
						</clipPath>
					</svg>
				</div>
				<!--div class="entry-meta">
					<i><img src="<?php echo esc_url( IMG_URI ); ?>/date-ic.png" alt="date-ic"></i>
					<div class="post-date"><?php echo get_the_date( 'd', get_the_ID() ); ?><span><?php echo get_the_date( 'F', get_the_ID() ); ?></span><span><?php echo get_the_date( 'Y', get_the_ID() ); ?></span></div>
				</div-->
			</div>
		</div>
		<?php
	} ?>

	<div class="post-detail">

		<?php
		if ( is_single() ) :
			the_title( '<h3 class="entry-title">', '</h3>' );
		else :
			the_title( sprintf( '<h3 class="entry-title"><a href="%s">', esc_url( get_permalink() ) ), '</a></h3>' );
		endif;
		?>

		<div class="entry-content">

			<?php
			if( is_single() ) {

				/* translators: %s: Name of current post */
				the_content( sprintf(
					esc_html__( 'Continue reading %s', "maxigen" ),
					the_title( '<span class="screen-reader-text">', '</span>', false )
				) );

				wp_link_pages( array(
					'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', "maxigen" ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', "maxigen" ) . ' </span>%',
					'separator'   => '<span class="screen-reader-text">, </span>',
				) );
			
				?>
				<div class="entry-meta">
					<?php 
						if( has_tag() ) {
							?>
							<div class="entry-tag">
								<ul>
									<li>
										<h4><?php esc_html_e( 'Tags:',"maxigen" ); ?></h4>
									</li>
									<?php the_tags( '<li>', '</li><li>', '</li>' ); ?>
								</ul>
							</div>
							<?php
						}
					
						if( has_category() ) {
							?>
							<div class="post-categories">
							<h4><?php esc_html_e( 'Category:',"maxigen" ); ?></h4>
								<?php the_category( ' , ' ); ?>
							</div>
							<?php
						}
					?>
				</div>
				<div class="social-with-us">
					<span><?php if( function_exists('get_simple_likes_button') ) { echo get_simple_likes_button( get_the_ID() ); } ?> </span>
					<span class="total-comment"><a href="<?php esc_url( comments_link() ); ?>"><i class="fa fa-comment-o"></i><?php comments_number(__( '0', "maxigen" ), __( '1', "maxigen" ),__( '(%) Comments', "maxigen" )); ?></a></span>
					<div class="social-share">
						<i class="fa fa-share-alt"></i><?php esc_html_e('Share It',"maxigen"); ?>
						<ul>
							<li class="facebook"><a href="javascript: void(0)" data-action="facebook" data-title="<?php the_title(); ?>" data-url="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-facebook"></i></a></li>
							<li class="googleplus"><a href="javascript: void(0)" data-action="google-plus" data-url="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-google-plus"></i></a></li>
							<li class="twitter"><a href="javascript: void(0)" data-action="twitter" data-title="<?php the_title(); ?>" data-url="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-twitter"></i></a></li>
							<li class="twitter"><a href="javascript: void(0)" data-action="dribbble" data-title="<?php the_title(); ?>" data-url="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-dribbble"></i></a></li>
						</ul>
					</div>
				</div>
				<?php
			}
			else {
				?>
				<div class="entry-meta">
					<span class="meta-posted_by"><?php esc_html_e( 'By ', "maxigen" ); ?><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author() ?></a></span>
					<span class="meta-posted_on"><?php esc_html_e( ' Posted on  ', "maxigen" ); ?><a href="<?php esc_url( the_permalink() ); ?>"><?php echo get_the_date("d F Y"); ?></a></span>
					<span class="meta-comments"><?php esc_html_e( ' Comment  ', "maxigen" ); ?><a href="<?php esc_url( comments_link() ); ?>"><?php comments_number(__( '(0)', "maxigen" ), __( '1', "maxigen" ),__( '(%) Comments', "maxigen" )); ?></a></span>
				</div>
				
				<?php the_excerpt(); ?>
				
				<div class="read-more-single">
					<a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e("READ MORE","maxigen"); ?></a>
				</div>
				
				<?php
			}
			?>

		</div>
		
		<?php 
		if( is_single() ) {
			?>
			<div class="about-author">

				<h3><?php esc_html_e('About Author',"maxigen"); ?></h3>
				<div class="author-intro">
					<?php
					$author_bio_avatar_size = apply_filters( 'maxigen_author_bio_avatar_size', 136 );
					echo get_avatar( get_the_author_meta( 'user_email' ), $author_bio_avatar_size );
					?>
					<h2 class="author-title"><?php echo get_the_author(); ?></h2>
					<div class="social-share">
						<ul>
							<li class="facebook"><a href="javascript: void(0)" data-action="facebook" data-title="<?php the_title(); ?>" data-url="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-facebook"></i></a></li>
							<li class="googleplus"><a href="javascript: void(0)" data-action="google-plus" data-url="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-google-plus"></i></a></li>
							<li class="twitter"><a href="javascript: void(0)" data-action="twitter" data-title="<?php the_title(); ?>" data-url="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-twitter"></i></a></li>
							<li class="twitter"><a href="javascript: void(0)" data-action="dribbble" data-title="<?php the_title(); ?>" data-url="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-dribbble"></i></a></li>
						</ul>
					</div>
					<p><?php the_author_meta( 'description' ); ?></p>
				</div>
			</div>
			<?php	
		} ?>
	</div>

</article>

<div class="clearfix"></div>