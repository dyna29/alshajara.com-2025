<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Maxigen
 * @since Maxigen 1.0
 */
?>
	<!-- Footer Main -->
	<footer class="footer-main container-fluid no-padding">
		<div class="container">
			<div class="row">
				<?php
				if ( is_active_sidebar( 'sidebar-3' ) ) { 
					?>
					<div class="col-md-6 col-sm-6">
						<?php dynamic_sidebar('sidebar-3'); ?>
					</div>
					<?php
				}

				if ( is_active_sidebar( 'sidebar-4' ) ) { 
					?>
					<div class="col-md-6 col-sm-6 twitter-widget">
						<?php dynamic_sidebar('sidebar-4'); ?>
					</div>
					<?php
				}
				
				if ( is_active_sidebar( 'sidebar-5' ) ) { 
					?>
					<div class="col-md-6 col-sm-6">
						<?php dynamic_sidebar('sidebar-5'); ?>
					</div>
					<?php
				}
				
				if ( is_active_sidebar( 'sidebar-6' ) ) { 
					?>
					<div class="col-md-6 col-sm-6">
						
						<?php dynamic_sidebar('sidebar-6'); ?>

					</div>
					<?php
				}?>
				<div class="footer-bottom col-md-12 col-sm-12 no-padding">
					<div class="row">
						<div class="col-md-7 col-sm-7">
							<nav class="navbar ow-navigation">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-footer" aria-expanded="false" aria-controls="navbar">
										<span class="sr-only"><?php esc_html_e("Toggle navigation", "maxigen"); ?></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
								</div>
								<div id="navbar-footer" class="navbar-collapse collapse">
									<?php
									if( has_nav_menu('ng_secondary_nav') ) :
										wp_nav_menu( array(
											'theme_location' => 'ng_secondary_nav',
											'container' => false,
											'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
											'depth' => 10,
											'menu_class' => 'nav navbar-nav',
											'walker' => new maxigen_nav_walker
										));
									endif;
								?>
								</div>
							</nav>
						</div>
						<div class="col-md-5 col-sm-5 copyright">
							<?php echo wpautop( maxigen_options('opt_footer_copyright') ); ?>
						</div>
					</div>
				</div><!-- Footer Bottom /- -->
			</div>
		</div><!-- Container /- -->
	</footer><!-- Footer Main /- -->

	<?php wp_footer(); ?>

</body>
</html>