<?php
if( has_nav_menu('ng_primary_nav') ) :
	wp_nav_menu( array(
		'theme_location' => 'ng_primary_nav',
		'container' => false,
		'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
		'menu_class' => 'nav navbar-nav',
		'depth' => 10 ,
		'walker' => new  maxigen_nav_walker
	));
endif;
?>