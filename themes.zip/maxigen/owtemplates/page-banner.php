<?php
	if( maxigen_checkstring( get_post_meta( get_the_ID(), 'maxigen_cf_page_header_img', true ) ) ) {
		$header_image = get_post_meta( get_the_ID(), 'maxigen_cf_page_header_img', true );
	}
	else {
		$header_image = IMG_URI . '/page-banner.jpg';
	}

	if( get_post_meta( get_the_ID(), 'maxigen_cf_page_title', true ) != "disable") :
		?>
	<div class="page-banner about-banner container-fluid no-padding" <?php if( maxigen_checkstring( $header_image ) ) { ?> style="background-image: url(<?php echo esc_url( $header_image ); ?>);"<?php } ?>>

			<div class="page-banner-shape">

				<svg height="100%" width="100%">

					<clipPath clipPathUnits="objectBoundingBox" id="banner-shape">

						<polygon points="0 0, 0 1, 1 1, 0.75 0"/>

					</clipPath>

				</svg>

			</div>

			<div class="container">

				<div class="page-banner-content">
					<h4 class="pull-left">
						<?php
						
						if( maxigen_checkstring( get_post_meta( get_the_ID(), 'maxigen_cf_page_small_title', true ) ) ) {
							?>
							<span><?php echo esc_attr( get_post_meta( get_the_ID(), 'maxigen_cf_page_small_title', true ) ); ?></span>
							<?php
						}
						elseif( is_home() ) {
							esc_html_e( 'Blog', "maxigen" );
						}
						elseif( is_404() ) {
							esc_html_e( '404 Error', "maxigen" );
						}
						elseif( is_search() ) {
							printf( esc_html__( 'Search Results for: %s', "maxigen" ), get_search_query() );
						}
						elseif( is_archive() ) {
							the_archive_title();
						}
						else {
							the_title();
						} ?>
					</h4>

					<?php
					if( function_exists( 'bcn_display' ) ) {
						?>
						<div class="breadcrumb">
							<?php bcn_display(); ?>
						</div>
						<?php
					}?>

				</div>

			</div>

		</div>
	
	<?php
endif; ?>