<?php
/**
 * The Header for our theme
 *
 *
 * @package WordPress
 * @subpackage Maxigen
 * @since Maxigen 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body data-offset="200" data-spy="scroll" data-target=".ow-navigation" <?php body_class(); ?>>

	<div id="site-loader" class="load-complete">
		<div class="loader">
			<div class="loader-inner ball-clip-rotate">
				<div></div>
		   </div>
		</div>
	</div>

	<header class="header-main container-fluid no-padding <?php if( maxigen_checkstring ( get_post_meta( get_the_ID(), 'maxigen_cf_menu_layout', true ) ) && ( get_post_meta( get_the_ID(), 'maxigen_cf_menu_layout', true ) ) == 'relative' ) echo 'header-relative' ?>">	
		<div class="container">
			<nav class="navbar ow-navigation">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only"><?php esc_html_e("Toggle navigation", "maxigen"); ?></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>					
					<div class="logo">
						<?php
							if( maxigen_checkstring( maxigen_options("opt_site_logo","url") ) && maxigen_options("opt_logo_select") == '2' ):
								?>
								<a class="image-logo navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( maxigen_options("opt_site_logo","url") ); ?>" alt=""/></a>
								<?php
							else:
								?>
								<a class="text-logo navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo get_bloginfo('title'); ?></a>
								<?php
							endif;
						?>
					</div>
					<div class="logo-one">
						<?php
							if( maxigen_checkstring( maxigen_options("opt_logo_selectsecond") ) ):
								?>
								<a class="text-logo navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_attr( maxigen_options("opt_logo_selectsecond") ); ?></a>
								<?php
							else:
								?>
								<!--<a class="image-logo navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( maxigen_options("opt_site_logo","url") ); ?>" alt=""/>-->
						
									<a class="text-logo navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="logo_second" src="<?php echo esc_url( maxigen_options("opt_site_logo","url") ); ?>" alt=""/>
									<!--<a class="text-logo navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo get_bloginfo('title'); ?></a>-->
								<?php
							endif;
						?>
					</div>
				</div>
				<div id="navbar" class="navbar-collapse collapse navbar-right">
					<?php get_template_part("owtemplates/navigation","menu"); ?>
				</div>
			</nav>
		</div>
	</header>
	<?php get_template_part("owtemplates/page","banner"); ?>