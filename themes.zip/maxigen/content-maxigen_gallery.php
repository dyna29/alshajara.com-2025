<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Maxigen
 * @since Maxigen 1.0
 */
 
$args = array(
	'post_type' => 'maxigen_gallery'
);

$qry = new WP_Query($args);

$gallery_grp_txt = get_post_meta( get_the_ID(), 'maxigen_cf_gallery_grp', true );
 
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<div class="gallery-single container-fluid no-padding">
		<div class="section-padding"></div>
		<div class="container">
			<?php echo maxigen_content('<div class="section-header"><h3>','</h3></div>',esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_singletitle', true ) )); ?>
			<div class="trip-detail">
					<?php echo wp_get_attachment_image( get_post_meta( get_the_ID(), 'maxigen_cf_singleimg_id', true ), "maxigen-1170-450" ); ?>
				<div class="trip-header">
					<h3><span><?php the_title(); ?></span> <span><?php echo get_the_date('F j, Y') ?></span></h3>
				</div>
				<p><?php echo esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_desc', true ) ); ?></p>
			</div>
			<div class="row">
			<?php
				if( maxigen_checkstring ( get_post_meta( get_the_ID(), 'maxigen_cf_title_one', true ) ) ||( get_post_meta( get_the_ID(), 'maxigen_cf_title_two', true ) ) || ( get_post_meta( get_the_ID(), 'maxigen_cf_title_three', true ) ) ) {
					?>
					<div class="col-md-6 schedule-detail">
						<?php echo maxigen_content( '<h3>','</h3>',esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_tabletitle', true ) ) );?>
						<table class="table table-bordered">
							<thead>
							  <tr>
								<?php echo maxigen_content('<th>','</th>',esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_title_one', true ) ) ); ?>
								<?php echo maxigen_content('<th>','</th>',esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_title_two', true ) ) ); ?>
								<?php echo maxigen_content('<th>','</th>',esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_title_three', true ) ) ); ?>
							  </tr>
							</thead>
							<tbody>
							<?php
								if( count( $gallery_grp_txt ) > 0 && is_array( $gallery_grp_txt ) ) {
									foreach ( (array) $gallery_grp_txt as $key => $value ) {	
										?>
										<tr>
											<?php
												if ( isset( $value['gallery_title'] ) ) {
													?>
													<td><?php echo esc_html( $value['gallery_title'] ); ?></td>
													<?php
												}
												if ( isset( $value['gallery_titlesecond'] ) ) {
													?>
													<td><?php echo esc_html( $value['gallery_titlesecond'] ); ?></td>
													<?php
												}
												if ( isset( $value['gallery_titlethree'] ) ) {
													?>
													<td><?php echo esc_html( $value['gallery_titlethree'] ); ?></td>
													<?php
												}
											?>
										</tr>
										<?php
									}
								}
							?>  
							</tbody>
						</table>	
					</div>
					<?php
				}
				if( maxigen_checkstring ( get_post_meta( get_the_ID(), 'maxigen_cf_latitute', true ) ) || ( get_post_meta( get_the_ID(), 'maxigen_cf_longitute', true ) ) || ( get_post_meta( get_the_ID(), 'maxigen_cf_mapaddress', true ) ) ) {
					?>
					<div class="col-md-6">
						<div class="gallery-single-map" id="map-canvas-contact" data-lat="<?php echo esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_latitute', true ) ); ?>" data-lng="<?php echo esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_longitute', true ) ); ?>" data-string="<?php echo esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_mapaddress', true ) ); ?>" data-marker="<?php echo esc_url( OWTH_LIB ).'images/marker.png'; ?>" data-zoom="12"></div>
					</div>
					<?php
					
				}
				if( maxigen_checkstring ( get_post_meta( get_the_ID(), 'maxigen_cf_single_desc', true ) ) ) {
					?>
					<div class="qoute-content col-md-12">
						<?php echo wpautop(esc_html( get_post_meta( get_the_ID(), 'maxigen_cf_single_desc', true ) ) ); ?>
					</div>
					<?php
				} 
				
				?>
				<div class="img-box container-fluid no-padding">
					<?php
						$ary_imgs = get_post_meta( get_the_ID(), 'maxigen_cf_gallery_img', true );
						foreach ( (array) $ary_imgs as $attachment_id => $attachment_url ) {
							
							if( maxigen_checkstring ( wp_get_attachment_image( $attachment_id) ) ) { 
								?>
								<div class="col-md-3 col-sm-3 col-xs-3 img-hover">
									<a href="<?php echo esc_url( $attachment_url ); ?>">
										<?php echo wp_get_attachment_image( $attachment_id, "maxigen-270-250" );?>
									</a>
								</div>
								<?php
							}
						}								
					?>
				</div>
			</div>
		</div>
		<div class="section-padding"></div>
	</div>
</article>
<div class="clearfix"></div>