<div id="aios-firewall-installed-notice" class='notice notice-success is-dismissible'>
	<p><strong><?php _e('All In One WP Security and Firewall', 'all-in-one-wp-security-and-firewall'); ?></strong></p>
	<p>
		<?php
		echo __('Your firewall has been installed with the highest level of protection.', 'all-in-one-wp-security-and-firewall').' '.
			__('You may have to wait 5 minutes for the changes to take effect.', 'all-in-one-wp-security-and-firewall');
		?>
	</p>
</div>