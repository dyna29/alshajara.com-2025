<?php
function maxigen_contact_map( $atts ) {
	
	extract( shortcode_atts(
		array(
			'vc_map_lati' => '',
			'vc_map_longi' => '',
			'vc_address' => ''
		), $atts )
	);

	ob_start();
	?>	
	<div class="map container-fluid no-padding">
		<div class="map-canvas" id="map-canvas-contact" data-lat="<?php echo esc_attr( $vc_map_lati ); ?>" data-lng="<?php echo esc_attr( $vc_map_longi ); ?>" data-string="<?php echo esc_attr( $vc_address ); ?>" data-marker="<?php echo esc_url( OWTH_LIB ).'images/marker.png'; ?>" data-zoom="12"></div>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode('maxigen_contact_map', 'maxigen_contact_map');

/* - Contact Map */
vc_map( array(
	"name" => esc_html("Contact Map", "maxigen-toolkit"),
	"icon" => 'vc-site-icon',
	"base" => "maxigen_contact_map",
	"category" => esc_html("Maxigen", "maxigen-toolkit"),
	"params" => array(		
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Map Latitute", "maxigen-toolkit"),
			"param_name" => "vc_map_lati",
			"description" => esc_html("e.g : -35.278930", "maxigen-toolkit"),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Map Longitute", "maxigen-toolkit"),
			"param_name" => "vc_map_longi",
			"description" => esc_html("e.g : 149.128125", "maxigen-toolkit"),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Map Address", "maxigen-toolkit"),
			"param_name" => "vc_address",
		),
	)
) );