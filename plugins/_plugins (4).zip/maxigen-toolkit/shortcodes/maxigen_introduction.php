<?php
function maxigen_introduction_outer( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'title' => '',
		'author' => '',
		'desc' => '',
		'stitle' => '',
		
		'extra_class' => '',

	), $atts ) );
	
	$result ="
		<div id='intro-section' class='container-fluid no-padding intro-section'>
			<div class='section-padding'></div>
				<div class='container'>
					<div class='row'>
						<div class='col-md-4 col-sm-6 col-xs-6 quotes'>
							<h4>$title</h4>
								<span>$author</span>
						</div>
						<div class='col-md-4 col-sm-6 col-xs-6 intro-slider'>
							<div class='intro-carousel'>
								".do_shortcode( $content )."
							</div>
						</div>
					<div class='col-md-4 col-sm-12 col-xs-12 content'>
						<p>$desc</p>
						<h5>$stitle</h5>
					</div>
				</div>
			</div>
			<div class='section-padding'></div>
			<div class='intro-shape'>
				<svg width='100%' height='100%'>
					<clipPath id='intro' clipPathUnits='objectBoundingBox'>
						<polygon points='0.5 0, 0 1, 1 1, 1 0'></polygon>
					</clipPath>
				</svg>
			</div>
		</div>";
		
		return $result;
}
add_shortcode( 'introduction_outer', 'maxigen_introduction_outer' );

function maxigen_introduction_inner( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'intro_image' => '',
		'title' => '',
		
		'extra_class' => ''

	), $atts ) );
	
	$intro_img = wp_get_attachment_image( $intro_image, 'maxigen-293-360' );

	$result = "
		<div class='intro-details $extra_class'>
			$intro_img
		</div>";

	return $result;
}
add_shortcode( 'introduction_inner', 'maxigen_introduction_inner' );

// Parent Element
function vc_introduction_outer() {

	// Register "container" content element. It will hold all your inner (child) content elements
	vc_map( array(
		"name" => __("Introduction", "maxigen-toolkit"),
		"base" => "introduction_outer",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"as_parent" => array('only' => 'introduction_inner'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => true,
		"is_container" => true,
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "textfield",
				"heading" => __("Authot Text", "maxigen-toolkit"),
				"param_name" => "title",
			),
			array(
				"type" => "textfield",
				"heading" => __("Authot Name", "maxigen-toolkit"),
				"param_name" => "author",
			),
			array(
				"type" => "textarea",
				"heading" => __("Description", "maxigen-toolkit"),
				"param_name" => "desc",
			),
			array(
				"type" => "textfield",
				"heading" => __("Sub Title", "maxigen-toolkit"),
				"param_name" => "stitle",
			),
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "seowave")
			)
		),
		"js_view" => 'VcColumnView'
	) );
}
add_action( 'vc_before_init', 'vc_introduction_outer' );

// Nested Element
function vc_introduction_inner() {

	vc_map( array(
		"name" => __("Single Introduction", "maxigen-toolkit"),
		"base" => "introduction_inner",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"content_element" => true,
		"as_child" => array('only' => 'introduction_outer'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "attach_image",
				"heading" => __("Introduction Image", "maxigen-toolkit"),
				"param_name" => "intro_image",
			),
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "seowave")
			)
		)
	) );
}
add_action( 'vc_before_init', 'vc_introduction_inner' );

// Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Introduction_Outer extends WPBakeryShortCodesContainer {
	}
}

if ( class_exists( 'WPBakeryShortCode' ) ) {

    class WPBakeryShortCode_Introduction_Inner extends WPBakeryShortCode {
    }
}
?>