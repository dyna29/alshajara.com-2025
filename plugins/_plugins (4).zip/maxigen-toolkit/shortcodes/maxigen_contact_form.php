<?php
function maxigen_contact_form( $atts, $content = null ) {

	extract( shortcode_atts(
		array(
			'title' => '',
			'stitle' => '',
			'desc' => '',
			'address' => '',
			'monfri' => '',
			'saturday' => '',
			'sunday' => '',
			'emailone' => '',
			'emailtwo' => '',
			'phoneone' => '',
			'phonetwo' => '',
		), $atts )
	);

	ob_start();
	?>

	<div class="contact-us container-fluid no-padding">
		<div class="section-padding"></div>
		<div class="container">
			<div class="section-header">
				<?php echo maxigen_content( '<h3>','</h3>',esc_attr($title) ); ?>
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="contect-box">
					<?php echo maxigen_content( '<h3>','</h3>',esc_attr($stitle) ); ?>
					<?php echo wpautop($desc); ?>
				</div>
				<div class="contact-info">
					<div class="row">
						<div class="col-md-6 col-sm-6 col-xs-6 contact-info-content">
							<h3><?php esc_html_e('Address',"maxigen-toolkit"); ?></h3>
							<?php echo maxigen_content('<p>','</p>',esc_html($address)); ?>
						</div>
						<div class="col-md-6 col-sm-6 col-xs-6 contact-info-content">
							<h3><?php esc_html_e('Business',"maxigen-toolkit"); ?></h3>
							<p><?php esc_html_e('Monday-Friday: ',"maxigen-toolkit"); ?><?php echo esc_html($monfri); ?></p>
							<p><?php esc_html_e('Saturday: ',"maxigen-toolkit"); ?><?php echo esc_html($saturday); ?></p>
							<p><?php esc_html_e('Sunday: ',"maxigen-toolkit"); ?><?php echo esc_html($sunday); ?></p>
						</div>
						<div class="col-md-6 col-sm-6 col-xs-6 contact-info-content">
							<h3><?php esc_html_e('Email Address',"maxigen-toolkit"); ?></h3>
							<p><a href="mailto:<?php echo esc_attr($emailone); ?>"><?php echo esc_attr($emailone); ?></a></p>
							<p><a href="mailto:<?php echo esc_attr($emailtwo); ?>"><?php echo esc_attr($emailtwo); ?></a></p>
						</div>
						<div class="col-md-6 col-sm-6 col-xs-6 contact-info-content">
							<h3><?php esc_html_e('Phone Number',"maxigen-toolkit"); ?></h3>
							<?php echo maxigen_content('<p>','</p>',esc_attr($phoneone)); ?>
							<?php echo maxigen_content('<p>','</p>',esc_attr($phonetwo)); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="conact-form-inner">
					<?php echo do_shortcode( $content ); ?>
				</div>
			</div>
		</div><!-- Container /- -->
	</div><!-- Contact Us /- -->
	<?php
	return ob_get_clean();
}
add_shortcode('maxigen_contact_form', 'maxigen_contact_form');

/* - Contact Form */
vc_map( array(
	"name" => esc_html("Contact Form", "maxigen-toolkit"),
	"icon" => 'vc-site-icon',
	"base" => "maxigen_contact_form",
	"category" => esc_html("Maxigen", "maxigen-toolkit"),
	"params" => array(
	
		array(
			"type" => "textfield",
			"heading" => __("Title", "maxigen-toolkit"),
			"param_name" => "title",
			"holder" => "div",
		),
		array(
			"type" => "textfield",
			"heading" => __("Sub Title", "maxigen-toolkit"),
			"param_name" => "stitle",
		),
		array(
			"type" => "textarea",
			"heading" => __("Short Description", "maxigen-toolkit"),
			"param_name" => "desc",
		),
		
		array(
			"type" => "textfield",
			"heading" => __("Contact Address", "maxigen-toolkit"),
			"param_name" => "address",
		),
		array(
			"type" => "textfield",
			"heading" => __("Business Time For Monday-TO-Friday", "maxigen-toolkit"),
			"param_name" => "monfri",
		),
		array(
			"type" => "textfield",
			"heading" => __("Business Time For Saturday", "maxigen-toolkit"),
			"param_name" => "saturday",
		),
		array(
			"type" => "textfield",
			"heading" => __("Business Time For Sunday", "maxigen-toolkit"),
			"param_name" => "sunday",
		),
		array(
			"type" => "textfield",
			"heading" => __("Email Address One", "maxigen-toolkit"),
			"param_name" => "emailone",
		),
		array(
			"type" => "textfield",
			"heading" => __("Email Address Second", "maxigen-toolkit"),
			"param_name" => "emailtwo",
		),
		array(
			"type" => "textfield",
			"heading" => __("Phone Number", "maxigen-toolkit"),
			"param_name" => "phoneone",
		),
		array(
			"type" => "textfield",
			"heading" => __("Phone Number Second", "maxigen-toolkit"),
			"param_name" => "phonetwo",
		),
		array(
			"type" => "textarea_html",
			"class" => "",
			"heading" => esc_html("Contact Form Shortcode", "maxigen-toolkit"),
			"description" => esc_html('Here Add Contact Form 7 Shortcode, e.g : [contact-form-7 id="47" title="Contact Page Form"]', "maxigen-toolkit"),
			"param_name" => "content",
			"holder" => "div",
		),
	)
) );	