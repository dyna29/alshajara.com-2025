<?php
function maxigen_about_outer( $atts, $content = null ) {

	extract( shortcode_atts( array(
		
		'bg' => '',
		'title' => '',
		
		'extra_class' => '',

	), $atts ) );
	
	if( maxigen_checkstring( $bg ) ) {
		$style= 'background-image:url('.wp_get_attachment_url($bg).');';
	}
	else {
		$style = "";
	}
	
	$result = "
	<div id='about-section' class='about-section about-margin container-fluid no-padding $extra_class' Style='".$style."' >		
		<div class='section-padding'></div>
		<div class='container'>
			<div class='section-header'>
				<h3>$title</h3>
			</div>
			<div class='row'>
				".do_shortcode( $content )."
			</div>
		</div>
		<div class='section-padding'></div>
	</div>";
		
	return $result;
}
add_shortcode( 'about_outer', 'maxigen_about_outer' );

function maxigen_about_inner( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'about_image' => '',
		'abouticon_image' => '',
		'title' => '',
		'desc' => '',
		'btntxt' => '',
		'btnurl' => '',
		
		'extra_class' => ''

	), $atts ) );
	
	$about_img = wp_get_attachment_image( $about_image, 'maxigen-272-335' );
	
	$abouticon_img = wp_get_attachment_image( $abouticon_image, 'maxigen-81-65' );

	$result = "
		<div class='col-md-3 col-sm-6 col-xs-6 $extra_class'>
			<div class='about-box'>
				<div class='about-img-box'>
					$about_img
				</div>
				<div class='about-hover-box'>
					<i>$abouticon_img</i>
					<h5>$title</h5>
					<p>$desc</p>
					<a href='".esc_url($btnurl)."'>$btntxt</a>
				</div>
			</div>
		</div>";

	return $result;
}
add_shortcode( 'about_inner', 'maxigen_about_inner' );

// Parent Element
function vc_about_outer() {

	// Register "container" content element. It will hold all your inner (child) content elements
	vc_map( array(
		"name" => __("About", "maxigen-toolkit"),
		"base" => "about_outer",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"as_parent" => array('only' => 'about_inner'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => true,
		"is_container" => true,
		"params" => array(
			// add params same as with any other content element
			
			array(
				"type" => "attach_image",
				"heading" => __("Background Image", "maxigen-toolkit"),
				"param_name" => "bg",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Title", "maxigen-toolkit"),
				"param_name" => "title",
				"holder" => "div",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "seowave")
			)
		),
		"js_view" => 'VcColumnView'
	) );
}
add_action( 'vc_before_init', 'vc_about_outer' );

// Nested Element
function vc_about_inner() {

	vc_map( array(
		"name" => __("Single About", "maxigen-toolkit"),
		"base" => "about_inner",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"content_element" => true,
		"as_child" => array('only' => 'about_outer'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			// add params same as with any other content element
			
			array(
				"type" => "attach_image",
				"heading" => __("About Image", "maxigen-toolkit"),
				"param_name" => "about_image",
			),
			
			array(
				"type" => "attach_image",
				"heading" => __("About Icon Image", "maxigen-toolkit"),
				"param_name" => "abouticon_image",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Title", "maxigen-toolkit"),
				"param_name" => "title",
				"holder" => "div",
			),
			
			array(
				"type" => "textarea",
				"heading" => __("Description", "maxigen-toolkit"),
				"param_name" => "desc",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Button Text", "maxigen-toolkit"),
				"param_name" => "btntxt",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Button URL", "maxigen-toolkit"),
				"param_name" => "btnurl",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "seowave")
			)
		)
	) );
}
add_action( 'vc_before_init', 'vc_about_inner' );

// Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_About_Outer extends WPBakeryShortCodesContainer {
	}
}

if ( class_exists( 'WPBakeryShortCode' ) ) {

    class WPBakeryShortCode_About_Inner extends WPBakeryShortCode {
    }
}
?>