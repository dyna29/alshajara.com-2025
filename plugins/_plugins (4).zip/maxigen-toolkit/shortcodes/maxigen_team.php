<?php
function maxigen_team_outer( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'title' => '',

		'extra_class' => ''

	), $atts ) );

	Global $team_cnt;
	
	$team_cnt = 0;
	
	$result = "
	<div id='team-section' class='container-fluid no-padding team-section $extra_class'>
		<div class='section-padding'></div>
		<div class='container'>
			<div class='section-header'>
				<h3>$title</h3>
			</div>
			<div class='row'>
				".do_shortcode( $content )."
			</div>
		</div>
	</div>";

	return $result;
}
add_shortcode( 'team_outer', 'maxigen_team_outer' );

function maxigen_team_inner( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'team_image' => '',
		'title' => '',
		'desc' => '',
		'address' => '',
		'fb_url' => '',
		'twitter_url' => '',
		'googleplus_url' => '',
		
		'extra_class' => ''

	), $atts ) );

	$team_img = wp_get_attachment_image( $team_image, 'maxigen-270-351' );
	
	Global $team_cnt;
	
	$team_cnt++;
	
	$result = "
		<div class='col-md-3 col-sm-6 col-xs-6 $extra_class'>
			<div class='team-box'>
				<div class='img-box'>
					$team_img
					<div id='team_shape-$team_cnt' class='team-shape'>
						<svg width='100%' height='100%'>
							<clipPath id='team-$team_cnt' clipPathUnits='objectBoundingBox'>
								<polygon points='0 0, 0 1, 1 0.93, 0 0'></polygon>
							</clipPath>
						</svg>
					</div>
					<div class='team-hover-box'>
						<ul>
							<li><a href='".esc_url( $fb_url )."'><i class='fa fa-facebook'></i></a></li>						
							<li><a href='".esc_url( $twitter_url )."'><i class='fa fa-twitter'></i></a></li>
							<li><a href='".esc_url( $googleplus_url )."' title='Google Plus'><i class='fa fa-google-plus'></i></a></li>
						</ul>
						<p>$desc</p>
					</div>
				</div>
				<h3>$title</h3>
				<p>$address</p>
			</div>
		</div>";

	return $result;
}
add_shortcode( 'team_inner', 'maxigen_team_inner' );

// Parent Element
function vc_team_outer() {

	// Register "container" content element. It will hold all your inner (child) content elements
	vc_map( array(
		"name" => __("Team", "maxigen-toolkit"),
		"base" => "team_outer",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"as_parent" => array('only' => 'team_inner'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => true,
		"is_container" => true,
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "textfield",
				"heading" => __("Title", "maxigen-toolkit"),
				"param_name" => "title",
			),
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "maxigen-toolkit")
			)
		),
		"js_view" => 'VcColumnView'
	) );
}
add_action( 'vc_before_init', 'vc_team_outer' );

// Nested Element
function vc_team_inner() {

	vc_map( array(
		"name" => __("Single Team", "maxigen-toolkit"),
		"base" => "team_inner",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"content_element" => true,
		"as_child" => array('only' => 'team_outer'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "attach_image",
				"heading" => __("Team Image", "maxigen-toolkit"),
				"param_name" => "team_image",
			),
			array(
				"type" => "textfield",
				"heading" => __("Title", "maxigen-toolkit"),
				"param_name" => "title",
				"holder" => "div",
			),
			array(
				"type" => "textfield",
				"heading" => __("Address", "maxigen-toolkit"),
				"param_name" => "address"
			),
			array(
				"type" => "textarea",
				"heading" => __("Description", "maxigen-toolkit"),
				"param_name" => "desc",
			),
			array(
				"type" => "textfield",
				"heading" => __("Facebook URL", "maxigen-toolkit"),
				"param_name" => "fb_url",
			),
			array(
				"type" => "textfield",
				"heading" => __("Twitter URL", "maxigen-toolkit"),
				"param_name" => "twitter_url",
			),
			array(
				"type" => "textfield",
				"heading" => __("Google Plus URL", "maxigen-toolkit"),
				"param_name" => "googleplus_url",
			),
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "maxigen-toolkit")
			)
		)
	) );
}
add_action( 'vc_before_init', 'vc_team_inner' );

// Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Team_Outer extends WPBakeryShortCodesContainer {
	}
}

if ( class_exists( 'WPBakeryShortCode' ) ) {

    class WPBakeryShortCode_Team_Inner extends WPBakeryShortCode {
    }
}
?>