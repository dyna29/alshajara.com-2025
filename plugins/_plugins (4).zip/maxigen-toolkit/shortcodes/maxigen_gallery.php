<?php
function ng_gallerys( $atts ) {

	extract( shortcode_atts(
		array(
			'title' => '',
			'btntxt' => '',
			'btnurl' => '',
			'per_page' => '',
			'owlayout' => ''
		), $atts )
	);

	
	if( '' === $per_page ) :
		$per_page = 8;
	endif;
	
	$args = array(
		'post_type' => 'maxigen_gallery',
		'posts_per_page' => $per_page,
		'order'   => 'ASC',
	);
	
	if( '' === $owlayout ) :	
		$owlayout = __('one', "maxigen-toolkit");
	endif;
	
	$qry = new WP_Query( $args );
	
	ob_start();
	
	if($owlayout == "one"){
		?>
		<div id="gallery-section" class="gallery-section container-fluid no-padding">
			<div class="section-padding"></div>
			<?php echo maxigen_content('<div class="section-header"><h3>','</h3></div>',esc_attr($title)); ?>
			<div class="gallery col-md-12 no-padding">
				<?php						
					while ( $qry->have_posts() ) : $qry->the_post();
						?>
						<div class="col-md-3 col-sm-4 col-xs-6 gallery-box no-padding">
							<?php the_post_thumbnail("maxigen-480-300" ); ?>
							<div class="gallery-box-hover">
								<?php the_title('<h5>','</h5>'); ?>
								<p><?php echo maxigen_custom_length( get_post_meta( get_the_ID(), 'maxigen_cf_desc', true ) ,14 ); ?></p>
								<a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e('Learn more',"maxigen-toolkit"); ?></a>
							</div>
						</div>
						<?php
					endwhile;
					// Reset Post Data
					wp_reset_postdata();
				?>
			</div>
			<?php echo maxigen_content('<a href=','>'.esc_attr($btntxt).'</a>',esc_url($btnurl)); ?>	
		</div>
		<?php
	}
	elseif($owlayout == "two"){
		?>
		<div id="gallery-section" class="gallery-section container-fluid no-padding">
			<div class="section-padding"></div>
			<?php echo maxigen_content('<div class="section-header"><h3>','</h3></div>',esc_attr($title)); ?>
			
			<div class="gallery container-fluid no-padding">
				<?php						
					while ( $qry->have_posts() ) : $qry->the_post();
						?>
						<div class="col-md-3 col-sm-4 col-xs-6 gallery-box no-padding">
							<?php the_post_thumbnail("maxigen-480-300" ); ?>
							<div class="gallery-box-hover">
								<?php the_title('<h5>','</h5>'); ?>
								<p><?php echo maxigen_custom_length( get_post_meta( get_the_ID(), 'maxigen_cf_desc', true ) ,14 ); ?></p>
								<a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e('Learn more',"maxigen-toolkit"); ?></a>
							</div>
						</div>
						<?php
					endwhile;
					// Reset Post Data
					wp_reset_postdata();
				?>
			</div>
			
			<?php echo maxigen_content('<a href=','>'.esc_attr($btntxt).'</a>',esc_url($btnurl)); ?>	
			
			<div class="section-padding container-fluid"></div>
		</div>
		<?php
	}
	return ob_get_clean();
}
add_shortcode('ng_gallerys', 'ng_gallerys');

vc_map( array(
	"name" => esc_html("Gallery", "maxigen-toolkit"),
	"icon" => 'vc-site-icon',
	"base" => "ng_gallerys",
	"category" => esc_html("Maxigen", "maxigen-toolkit"),
	"params" => array(
		array(
			'type' => 'dropdown',
			'class' => '',
			'holder' => 'div',
			'heading' => __( 'Layout', "maxigen-toolkit"),
			'param_name' => 'owlayout',
			'value' =>array(
				'Layout one' => 'one',
				'Layout two'=> 'two',
			),
			'description' => __( 'Select Post Layout. Default Layout 1 Select', "maxigen-toolkit"),
		),	
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Title", "maxigen-toolkit"),
			"param_name" => "title",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Button Text", "maxigen-toolkit"),
			"param_name" => "btntxt",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Button Url", "maxigen-toolkit"),
			"param_name" => "btnurl",
			
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Post Per Page", "maxigen-toolkit"),
			"param_name" => "per_page",
			"holder" => "div",
		),
	)
) );