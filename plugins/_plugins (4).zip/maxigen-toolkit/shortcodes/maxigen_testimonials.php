<?php
function maxigen_testimonials_outer( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'title' => '',
		'extra_class' => ''

	), $atts ) );
	
	$str_slide = "";
	
	$cnt_active = "";
	
	$result = "";
	
	for( $cnt=0; $cnt < substr_count($content, 'testimonials_inner'); $cnt++ ) {
		if( $cnt == 0 ) {
			$cnt_active = "class='active'";
		} else {
			$cnt_active = "";
		}
		$str_slide .= "<li data-target='#main-carousel-1' data-slide-to='$cnt' $cnt_active ></li>";
	}
	
	$result = "
		<div class='testimonial container-fluid no-padding $extra_class'>
			<div class='section-padding'></div>
			<div class='container'>
				<div class='section-header'>
					<h3>$title</h3>
				</div>
				<div id='main-carousel-1' class='carousel slide' data-ride='carousel'>
					 <ol class='carousel-indicators'>";
						$result .= "$str_slide";
					
						$result .= "
						
					</ol>
					<div class='carousel-inner' role='listbox'>
						".do_shortcode( $content )."
					</div>
				</div>
			</div>
			<div class='section-padding'></div>
		</div>";

	return $result;
}
add_shortcode( 'testimonials_outer', 'maxigen_testimonials_outer' );

function maxigen_testimonials_inner( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'testimonials_image' => '',
		'desc' => '',
		'extra_class' => ''

	), $atts ) );

	$testimonials_img = wp_get_attachment_image( $testimonials_image, 'maxigen-96-96' );

	$result = "
		<div class='item item-content $extra_class'>
			<span>$testimonials_img</span>
			<p>$desc</p>
		</div>";

	return $result;
}
add_shortcode( 'testimonials_inner', 'maxigen_testimonials_inner' );

// Parent Element
function vc_testimonials_outer() {

	// Register "container" content element. It will hold all your inner (child) content elements
	vc_map( array(
		"name" => __("Testimonials", "maxigen-toolkit"),
		"base" => "testimonials_outer",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"as_parent" => array('only' => 'testimonials_inner'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => true,
		"is_container" => true,
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "textfield",
				"heading" => __("Title", "maxigen-toolkit"),
				"param_name" => "title",
				"holder"=> "div",
			),
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "maxigen-toolkit")
			)
		),
		"js_view" => 'VcColumnView'
	) );
}
add_action( 'vc_before_init', 'vc_testimonials_outer' );

// Nested Element
function vc_testimonials_inner() {

	vc_map( array(
		"name" => __("Single Testimonials", "maxigen-toolkit"),
		"base" => "testimonials_inner",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"content_element" => true,
		"as_child" => array('only' => 'testimonials_outer'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "attach_image",
				"heading" => __("Testimonials Image", "maxigen-toolkit"),
				"param_name" => "testimonials_image",
			),
			array(
				"type" => "textarea",
				"heading" => __("Description", "maxigen-toolkit"),
				"param_name" => "desc",
			),
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "maxigen-toolkit")
			)
		)
	) );
}
add_action( 'vc_before_init', 'vc_testimonials_inner' );

// Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Testimonials_Outer extends WPBakeryShortCodesContainer {
	}
}

if ( class_exists( 'WPBakeryShortCode' ) ) {

    class WPBakeryShortCode_Testimonials_Inner extends WPBakeryShortCode {
    }
}
?>