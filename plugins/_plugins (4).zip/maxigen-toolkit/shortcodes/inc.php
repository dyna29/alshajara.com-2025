<?php
if( !function_exists('maxigen_sc_setup') ) :

	function maxigen_sc_setup() {

		/* Script For Shortcodes */
		add_image_size( 'maxigen-1920-1060', 1920, 1060, true ); // Photoslider 
		add_image_size( 'maxigen-293-360', 293, 360, true ); // Introduction
		add_image_size( 'maxigen-1920-800', 1920, 800, true ); // Place
		add_image_size( 'maxigen-272-365', 272, 365, true ); // About
		add_image_size( 'maxigen-81-65', 81, 65, true ); // About Icon
		add_image_size( 'maxigen-270-351', 270, 351, true ); // Team
		add_image_size( 'maxigen-82-77', 82, 77, true ); // Client
		add_image_size( 'maxigen-96-96', 96, 96, true ); // Testimonials
		add_image_size( 'maxigen-480-300', 480, 300, true ); // Gallery
		add_image_size( 'maxigen-370-260', 370, 260, true ); // Blog
	}

	add_action( 'after_setup_theme', 'maxigen_sc_setup' );
endif;

/**
 * Shortcode for WP function get_template_directory_uri();
 */
if( !function_exists("maxigen_theme_dir") ) :

	function maxigen_theme_dir() {

		$dir = get_template_directory_uri();
		return $dir;
	}
	add_shortcode( 'maxigen_theme_dir', 'maxigen_theme_dir' );
endif;

if( function_exists('vc_map') ) {

	vc_add_param("vc_row", array(
		"type" => "dropdown",
		"group" => "Page Layout",
		"class" => "",
		"heading" => "Type",
		"param_name" => "type",
		'value' => array(
			esc_html( 'Default', "maxigen-toolkit") => 'default-layout',
			esc_html( 'Fixed', "maxigen-toolkit") => 'container',
		),
	));

	/* Include all individual shortcodes. */
	$prefix_nextgen = "maxigen_";

	require_once( $prefix_nextgen . "photoslider.php" );
	
	require_once( $prefix_nextgen . "introduction.php" );
	
	require_once( $prefix_nextgen . "place.php" );
	
	require_once( $prefix_nextgen . "about.php" );
	
	require_once( $prefix_nextgen . "team.php" );
	
	require_once( $prefix_nextgen . "client.php" );
	
	require_once( $prefix_nextgen . "blog.php" );
	
	require_once( $prefix_nextgen . "testimonials.php" );
	
	require_once( $prefix_nextgen . "map.php" );
	
	require_once( $prefix_nextgen . "contact_form.php" );
	
	require_once( $prefix_nextgen . "gallery.php" );
}