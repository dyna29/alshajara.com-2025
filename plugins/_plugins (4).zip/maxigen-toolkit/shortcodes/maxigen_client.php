<?php
function maxigen_client_outer( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'extra_class' => ''

	), $atts ) );

	$result = "
		<div id='client-section' class='client-section container-fluid no-padding $extra_class'>
			<div class='container'>
				<div class='client-carousel'>
					".do_shortcode( $content )."
				</div>
			</div>
		</div>";

	return $result;
}
add_shortcode( 'client_outer', 'maxigen_client_outer' );

function maxigen_client_inner( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'client_image' => '',
		'imglink' => '',

	), $atts ) );

	$client_img = wp_get_attachment_image( $client_image, 'maxigen-82-77' );

	$result = "
		<a href='".esc_url($imglink)."'>
			$client_img
		</a>";

	return $result;
}
add_shortcode( 'client_inner', 'maxigen_client_inner' );

// Parent Element
function vc_client_outer() {

	// Register "container" content element. It will hold all your inner (child) content elements
	vc_map( array(
		"name" => __("Client", "maxigen-toolkit"),
		"base" => "client_outer",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"as_parent" => array('only' => 'client_inner'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => true,
		"is_container" => true,
		"params" => array(
			// add params same as with any other content element
			
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "maxigen-toolkit")
			)
		),
		"js_view" => 'VcColumnView'
	) );
}
add_action( 'vc_before_init', 'vc_client_outer' );

// Nested Element
function vc_client_inner() {

	vc_map( array(
		"name" => __("Single Client", "maxigen-toolkit"),
		"base" => "client_inner",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"content_element" => true,
		"as_child" => array('only' => 'client_outer'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "attach_image",
				"heading" => __("Client Image", "maxigen-toolkit"),
				"param_name" => "client_image",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Client Image Link", "maxigen-toolkit"),
				"param_name" => "imglink",
				"holder" => "div",
			),
		)
	) );
}
add_action( 'vc_before_init', 'vc_client_inner' );

// Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Client_Outer extends WPBakeryShortCodesContainer {
	}
}

if ( class_exists( 'WPBakeryShortCode' ) ) {

    class WPBakeryShortCode_Client_Inner extends WPBakeryShortCode {
    }
}
?>