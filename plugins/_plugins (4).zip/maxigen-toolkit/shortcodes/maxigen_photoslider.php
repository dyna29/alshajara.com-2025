<?php
function maxigen_photoslider_outer( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'title' => '',
	
		'extra_class' => '',
		

	), $atts ) );
	
	Global $slide_cnt;
	
	$photoslider_image = "";
	
	$slide_cnt = 0;
	
	$str_slide = "";
	
	$str_sliderdata = "";
	
	$result = "";
	
	$cnt_active = "";
	
	for( $cnt=0; $cnt < substr_count($content, 'photoslider_inner'); $cnt++ ) {
		if( $cnt == 0 ) {
			$cnt_active = "class='active'";
		} else {
			$cnt_active = "";
		}
		$str_slide .= "<li data-target='#main-carousel' data-slide-to='$cnt' $cnt_active ></li>";
	}
	
	preg_match_all('/".*?"|\'.*?\'/', $content, $matches);
	foreach ($matches[0] as $key => $value) {
		if (!is_numeric(str_replace('"', '', $value))) {
			unset($matches[0][$key]);
		}
	}
	
	$img_ids = implode(',', $matches[0]);
	$arr_imgs = explode(",",str_replace('"', '', $img_ids));

	for( $cont_cnt=0; $cont_cnt < count($arr_imgs); $cont_cnt++ ) {
		$photoslider_image .= "<a href='#' data-target='#main-carousel' data-slide-to='$cont_cnt'>";  
		
		$photoslider_image .= wp_get_attachment_image($arr_imgs[$cont_cnt]);
			
			$photoslider_image.= "</a>";
	}
		
	$result = "
		<div id='photo-slider' class='photo-slider container-fluid no-padding $extra_class'>		
			<div id='main-carousel' class='carousel slide' data-ride='carousel'>
				<ol class='carousel-indicators'>";
					
					$result .= "$str_slide";
					
					$result .= "
				</ol>
				<div class='carousel-inner' role='listbox'>
					".do_shortcode( $content )."
				</div>
			</div>
			<div class='hot-box'>
				<div class='container'>
					<h4>$title</h4>";
					
					$result .= "$photoslider_image";
					
					$result .= "
					
				</div>
			</div>
		</div>";
		
	return $result;
}
add_shortcode( 'photoslider_outer', 'maxigen_photoslider_outer' );

function maxigen_photoslider_inner( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'photoslider_image' => '',
		'title' => '',
		'btntxt' => '',
		'btnurl' => '',
		'sbtntxt' => '',
		'sbtnurl' => '',
		
		'extra_class' => ''

	), $atts ) );
	
	$photoslider_img = wp_get_attachment_image( $photoslider_image, 'maxigen-1920-1060' );
	
	Global $slide_cnt;
	$slide_cnt++;
	$result = "
		<div class='item $extra_class'>
			<div id='slider_shape-$slide_cnt' class='slider-shape'>
				<svg width='100%' height='100%'>
					<clipPath id='slider-$slide_cnt' clipPathUnits='objectBoundingBox'>
						<polygon points='0 0, 0 1, 1 1, 0.5 0'></polygon>
					</clipPath>
				</svg>
			</div>
			$photoslider_img					
			<div class='carousel-caption'>
				<div class='container'>
					<h3>$title</h3>
					<a href='".esc_url( $btnurl )."' class='contact'>$btntxt</a>
					<a href='".esc_url( $sbtnurl )."' class='contact'>$sbtntxt</a>
				</div>
			</div>
		</div>";

	return $result;
}
add_shortcode( 'photoslider_inner', 'maxigen_photoslider_inner' );

// Parent Element
function vc_photoslider_outer() {

	// Register "container" content element. It will hold all your inner (child) content elements
	vc_map( array(
		"name" => __("Photo Slider", "maxigen-toolkit"),
		"base" => "photoslider_outer",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"as_parent" => array('only' => 'photoslider_inner'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => true,
		"is_container" => true,
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "textfield",
				"heading" => __("Title", "maxigen-toolkit"),
				"param_name" => "title",
			),
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "seowave")
			)
		),
		"js_view" => 'VcColumnView'
	) );
}
add_action( 'vc_before_init', 'vc_photoslider_outer' );

// Nested Element
function vc_photoslider_inner() {

	vc_map( array(
		"name" => __("Single Photo Slider", "maxigen-toolkit"),
		"base" => "photoslider_inner",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"content_element" => true,
		"as_child" => array('only' => 'photoslider_outer'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "attach_image",
				"heading" => __("photoslider Image", "maxigen-toolkit"),
				"param_name" => "photoslider_image",
			),
			array(
				"type" => "textfield",
				"heading" => __("Title", "maxigen-toolkit"),
				"param_name" => "title",
			),
			array(
				"type" => "textfield",
				"heading" => __("Button Text One", "maxigen-toolkit"),
				"param_name" => "btntxt",
			),
			array(
				"type" => "textfield",
				"heading" => __("Button URL One", "maxigen-toolkit"),
				"param_name" => "btnurl",
			),
			array(
				"type" => "textfield",
				"heading" => __("Button Text Two", "maxigen-toolkit"),
				"param_name" => "sbtntxt",
			),
			array(
				"type" => "textfield",
				"heading" => __("Button URL Two", "maxigen-toolkit"),
				"param_name" => "sbtnurl",
			),
		)
	) );
}
add_action( 'vc_before_init', 'vc_photoslider_inner' );

// Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Photoslider_Outer extends WPBakeryShortCodesContainer {
	}
}

if ( class_exists( 'WPBakeryShortCode' ) ) {

    class WPBakeryShortCode_Photoslider_Inner extends WPBakeryShortCode {
    }
}
?>