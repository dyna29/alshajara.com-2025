<?php
function maxigen_place_outer( $atts, $content = null ) {

	extract( shortcode_atts( array(
		
		'prevtxt' => '',
		'nexttxt' => '',
		'extra_class' => '',

	), $atts ) );
	
	$result = "
		<div id='places-section' class='places-section container-fluid no-padding'>
			<div id='places-carousel' class='carousel slide' data-ride='carousel'>
				<div class='carousel-inner' role='listbox'>
					".do_shortcode( $content )."
				</div>	
				<a class='left carousel-control' href='#places-carousel' role='button' data-slide='prev'>
					<span>$prevtxt</span>
				</a>
				<a class='right carousel-control' href='#places-carousel' role='button' data-slide='next'>
					<span>$nexttxt</span>
				</a>
			</div>
		</div>";
		
	return $result;
}
add_shortcode( 'place_outer', 'maxigen_place_outer' );

function maxigen_place_inner( $atts, $content = null ) {

	extract( shortcode_atts( array(

		'place_image' => '',
		'desc' => '',
		'title' => '',
		'temp' => '',
		'tno' => '',
		'sel' => '',
		'tsel' => '',
		'interval' => '',
		'time' => '',
		'duration' => '',
		'day' => '',
		'hight' => '',
		'hightft' => '',
		
		'extra_class' => ''

	), $atts ) );
	
	$place_img = wp_get_attachment_image( $place_image, 'maxigen-1920-800' );

	$result = "
		<div class='item $extra_class'>						
			<div class='carousel-caption'>
				<div class='col-md-7 col-sm-7 col-xs-7 places-content no-padding'>
					<p>$desc</p>
					<h5>$title</h5>
					<div class='places-details col-md-12 no-padding'>
						<div class='col-md-3 col-sm-6 col-xs-3 details-box'>
							<h3>$temp<span>$tno<sup>$sel</sup>$tsel</span></h3>
						</div>
						<div class='col-md-3 col-sm-6 col-xs-3 details-box'>
							<h3>$interval<span>$time</span></h3>
						</div>
						<div class='col-md-3 col-sm-6 col-xs-3 details-box'>
							<h3>$duration<span>$day</span></h3>
						</div>
						<div class='col-md-3 col-sm-6 col-xs-3 details-box'>
							<h3>$hight<span>$hightft</span></h3>
						</div>
					</div>
				</div>
			</div>
			$place_img
		</div>";

	return $result;
}
add_shortcode( 'place_inner', 'maxigen_place_inner' );

// Parent Element
function vc_place_outer() {

	// Register "container" content element. It will hold all your inner (child) content elements
	vc_map( array(
		"name" => __("Place", "maxigen-toolkit"),
		"base" => "place_outer",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"as_parent" => array('only' => 'place_inner'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => true,
		"is_container" => true,
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "textfield",
				"heading" => __("Previous Text", "maxigen-toolkit"),
				"param_name" => "prevtxt",
				"holder" => "div",
			),
			array(
				"type" => "textfield",
				"heading" => __("Next Text", "maxigen-toolkit"),
				"param_name" => "nexttxt",
				"holder" => "div",
			),
			array(
				"type" => "textfield",
				"heading" => __("Extra class name", "maxigen-toolkit"),
				"param_name" => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "seowave")
			)
		),
		"js_view" => 'VcColumnView'
	) );
}
add_action( 'vc_before_init', 'vc_place_outer' );

// Nested Element
function vc_place_inner() {

	vc_map( array(
		"name" => __("Single Place", "maxigen-toolkit"),
		"base" => "place_inner",
		"category" => esc_html__('Maxigen', "maxigen-toolkit"),
		"content_element" => true,
		"as_child" => array('only' => 'place_outer'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "attach_image",
				"heading" => __("Place Image", "maxigen-toolkit"),
				"param_name" => "place_image",
			),
			
			array(
				"type" => "textarea",
				"heading" => __("Description", "maxigen-toolkit"),
				"param_name" => "desc",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Title", "maxigen-toolkit"),
				"param_name" => "title",
				"holder" => "div",
			),
			
			array(
				"type" => "textfield",
				"heading" => __(" Temperature Text", "maxigen-toolkit"),
				"param_name" => "temp",
			),
			
			array(
				"type" => "textfield",
				"heading" => __(" Total Temperature", "maxigen-toolkit"),
				"param_name" => "tno",
			),
			
			array(
				"type" => "textfield",
				"heading" => __(" Temperature Point", "maxigen-toolkit"),
				"param_name" => "sel",
				"description" => esc_html('Example For 0', "maxigen-toolkit"),
			),
			
			array(
				"type" => "textfield",
				"heading" => __(" Celsius Text", "maxigen-toolkit"),
				"param_name" => "tsel",
				"description" => esc_html('Example For C', "maxigen-toolkit"),
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Interval Text", "maxigen-toolkit"),
				"param_name" => "interval",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Interval Time", "maxigen-toolkit"),
				"param_name" => "time",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Duration Text", "maxigen-toolkit"),
				"param_name" => "duration",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Duration Day", "maxigen-toolkit"),
				"param_name" => "day",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Hight Text", "maxigen-toolkit"),
				"param_name" => "hight",
			),
			
			array(
				"type" => "textfield",
				"heading" => __("Hight No", "maxigen-toolkit"),
				"param_name" => "hightft",
			),
		)
	) );
}
add_action( 'vc_before_init', 'vc_place_inner' );

// Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Place_Outer extends WPBakeryShortCodesContainer {
	}
}

if ( class_exists( 'WPBakeryShortCode' ) ) {

    class WPBakeryShortCode_Place_Inner extends WPBakeryShortCode {
    }
}
?>