<?php
function maxigen_blog( $atts ) {

	extract( shortcode_atts(
		array(
			'title' => '',
			'posts_display' => ''
		), $atts )
	);

	/* Post Arguments */
	$args = array(
		'posts_per_page' => $posts_display,
		'ignore_sticky_posts' => 1
	);
	
	$qry = new WP_Query( $args );
	
	$post_format = get_post_format();
	
	if( '' === $posts_display ) :
		$posts_display = 3;		
	endif;
	
	ob_start();

	?>

	<div id="blog-section" class="blog-section container-fluid no-padding">
		<div class="section-padding"></div>
		<div class="container">
			<?php echo maxigen_content('<div class="section-header"><h3>','</h3></div>', esc_attr( $title ) ); ?>	
			
			<?php
			if( $qry->have_posts() ) {
				?>
				<div class="row">
					<?php 
						$cnt = 1;
						while ( $qry->have_posts() ) : $qry->the_post();
							?>
							<div class="col-md-4 col-sm-6 col-xs-6">
								<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
								<?php
								if( has_post_thumbnail() && ( $post_format != "audio" && $post_format != "video" && $post_format != "gallery" ) ) {
										?>
									<div class="entry-cover">
										<a href="<?php echo esc_url( get_permalink() ); ?>">
										
											<?php the_post_thumbnail('maxigen-370-260'); ?>
										</a>
										<div class="triangle-shape" id="triangle-<?php the_ID(); ?>">
											<svg height="100" width="100">
												<clipPath clipPathUnits="objectBoundingBox" id="triangle_shape-<?php the_ID(); ?>">
													<polygon points="1 0, 0 1, 1 1, 1 0"/>
												</clipPath>
											</svg>
										</div>
										<div class="entry-meta">
											<i><img src="<?php echo esc_url( IMG_URI ); ?>/date-ic.png" alt="date-ic"></i>
											<div class="post-date"><?php echo get_the_date( 'd', get_the_ID() ); ?><span><?php echo get_the_date( 'F', get_the_ID() ); ?></span><span><?php echo get_the_date( 'Y', get_the_ID() ); ?></span></div>
										</div>
									</div>
									<?php
								}?>	
									<h3 class="entry-title">
										<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title() ?></a>
									</h3>
									<div class="entry-content">
										<p><?php maxigen_custom_excerpts(20); ?></p>
									</div>
								</article>
							</div>
							<?php
							$cnt++;
						endwhile;

						// Reset Original Data
						wp_reset_postdata();
						?>
				</div>
				<?php
			}
			?>
		</div>
		<div class="section-padding"></div>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode('maxigen_blog', 'maxigen_blog');

/* - Blog */
vc_map( array(
	"name" => esc_html("Blog", "maxigen-toolkit"),
	"icon" => 'vc-site-icon',
	"base" => "maxigen_blog",
	"category" => esc_html("Maxigen", "maxigen-toolkit"),
	"params" => array(
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Title", "maxigen-toolkit"),
			"param_name" => "title",
			"holder" => "div",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html("Post Per Page Display", "maxigen-toolkit"),
			"param_name" => "posts_display",
			"holder" => "div",
		),
	)
) );