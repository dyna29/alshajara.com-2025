<?php
// Start with an underscore to hide fields from custom fields list
$prefix = 'maxigen_cf_';

/* - Images */
$cmb_gallery = new_cmb2_box( array(
	'id'            => $prefix . 'metabox_gallery_image',
	'title'         => esc_html( 'Gallery Header', "maxigen-toolkit"),
	'object_types'  => array( 'maxigen_gallery' ), // Post type
	'context'       => 'normal',
	'closed'      => false,
	'show_names'    => true, // Show field names on the left
) );

$cmb_gallery->add_field( array(
	'name'         => __( 'Description', "maxigen-toolkit"),
	'id'           => $prefix . 'desc',
	'type'    => 'wysiwyg',
    'options' => array(
        'wpautop' => true, // use wpautop?
        'media_buttons' => true, // show insert/upload button(s)
        'textarea_rows' => get_option('default_post_edit_rows', 10), // rows="..."
        'tabindex' => '',
        'editor_css' => '', // intended for extra styles for both visual and HTML editors buttons, needs to include the `<style>` tags, can use "scoped".
        'editor_class' => '', // add extra class(es) to the editor textarea
        'teeny' => false, // output the minimal editor config used in Press This
        'dfw' => false, // replace the default fullscreen with DFW (needs specific css)
        'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
        'quicktags' => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
    ),
) );

$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Single Page Title', "maxigen-toolkit"),
	'id'           => $prefix . 'singletitle',
	'type'         => 'text',
) );

$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Single Page Image', "maxigen-toolkit"),
	'id'           => $prefix . 'singleimg',
	'type'         => 'file',
) );

$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Single Page Table Heading', "maxigen-toolkit"),
	'id'           => $prefix . 'tabletitle',
	'type'         => 'text',
) );

$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Tabel Sub Heading 1', "maxigen-toolkit"),
	'id'           => $prefix . 'title_one',
	'type'         => 'text',
) );

$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Tabel Sub Heading 2', "maxigen-toolkit"),
	'id'           => $prefix . 'title_two',
	'type'         => 'text',
) );

$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Tabel Sub Heading 3', "maxigen-toolkit"),
	'id'           => $prefix . 'title_three',
	'type'         => 'text',
) );

$cmb_grp_gallery = $cmb_gallery->add_field( array(
	'id'          => $prefix . 'gallery_grp',
	'type'        => 'group',
	'options'     => array(
		'group_title'   => __( 'Content Box {#}', "maxigen-toolkit"), // {#} gets replaced by row number
		'add_button'    => __( 'Add Item', "maxigen-toolkit"),
		'remove_button' => __( 'Remove Item', "maxigen-toolkit"),
	),
) );
$cmb_gallery->add_group_field( $cmb_grp_gallery, array(
	'name'       => __( 'Title', "maxigen-toolkit"),
	'id'         => 'gallery_title',
	'type' => 'text',
) );
$cmb_gallery->add_group_field( $cmb_grp_gallery, array(
	'name'       => __( 'Title', "maxigen-toolkit"),
	'id'         => 'gallery_titlesecond',
	'type' => 'text',
) );
$cmb_gallery->add_group_field( $cmb_grp_gallery, array(
	'name'       => __( 'Title', "maxigen-toolkit"),
	'id'         => 'gallery_titlethree',
	'type' => 'text',
) );
$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Map Latitute', "maxigen-toolkit"),
	'id'           => $prefix . 'latitute',
	'type'         => 'text',
) );
$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Map Longitute', "maxigen-toolkit"),
	'id'           => $prefix . 'longitute',
	'type'         => 'text',
) );
$cmb_gallery->add_field( array(
	'name'         => esc_html( 'Map Address', "maxigen-toolkit"),
	'id'           => $prefix . 'mapaddress',
	'type'         => 'text',
) );

$cmb_gallery->add_field( array(
	'name'         => __( 'Single Page Description', "maxigen-toolkit"),
	'id'           => $prefix . 'single_desc',
	'type'    => 'wysiwyg',
    'options' => array(
        'wpautop' => true, // use wpautop?
        'media_buttons' => true, // show insert/upload button(s)
        'textarea_rows' => get_option('default_post_edit_rows', 5), // rows="..."
        'tabindex' => '',
        'editor_css' => '', // intended for extra styles for both visual and HTML editors buttons, needs to include the `<style>` tags, can use "scoped".
        'editor_class' => '', // add extra class(es) to the editor textarea
        'teeny' => false, // output the minimal editor config used in Press This
        'dfw' => false, // replace the default fullscreen with DFW (needs specific css)
        'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
        'quicktags' => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
    ),
) );

$cmb_gallery->add_field( array(
	'name' => __( 'Images', "maxigen-toolkit"),
	'id'   => $prefix . 'gallery_img',
	'type' => 'file_list',
) );
?>