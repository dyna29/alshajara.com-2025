<?php
/**
 * Social Icons widget class MAXIGEN
 *
 * @since 2.8.0
 */
class MAXIGEN_Widget_Social extends WP_Widget {

	public function __construct() {

		$widget_ops = array('classname' => 'widget_social_icons', 'description' => esc_html( 'A Social Icons Widget.', "maxigen-toolkit") );
		parent::__construct( 'social_icons', _x( 'MAXIGEN :: Social Icons', 'Social Icons widget' , "maxigen-toolkit"), $widget_ops );
	}

	public function widget( $args, $instance ) {

		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo html_entity_decode( $args['before_widget'] ); // Widget starts to print information

		if ( $title ) {
			echo html_entity_decode( $args['before_title'] . $title . $args['after_title'] );
		}

		$social_facebook = empty( $instance['social_facebook'] ) ? '' : $instance['social_facebook'];
		$social_twitter = empty( $instance['social_twitter'] ) ? '' : $instance['social_twitter'];
		$social_googleplus = empty( $instance['social_googleplus'] ) ? '' : $instance['social_googleplus'];
		$social_linkedin = empty( $instance['social_linkedin'] ) ? '' : $instance['social_linkedin'];
		$social_instagram = empty( $instance['social_instagram'] ) ? '' : $instance['social_instagram'];
		$social_dribbble = empty( $instance['social_dribbble'] ) ? '' : $instance['social_dribbble'];
		$social_pinterest = empty( $instance['social_pinterest'] ) ? '' : $instance['social_pinterest'];
		$social_apple = empty( $instance['social_apple'] ) ? '' : $instance['social_apple'];
		$social_tumblr = empty( $instance['social_tumblr'] ) ? '' : $instance['social_tumblr'];
		$social_skype = empty( $instance['social_skype'] ) ? '' : $instance['social_skype'];
		$social_flickr = empty( $instance['social_flickr'] ) ? '' : $instance['social_flickr'];
		$social_youtube_play = empty( $instance['social_youtube_play'] ) ? '' : $instance['social_youtube_play'];
		$social_dropbox = empty( $instance['social_dropbox'] ) ? '' : $instance['social_dropbox'];
		$social_foursquare = empty( $instance['social_foursquare'] ) ? '' : $instance['social_foursquare'];
		
		
		?>

		<ul>
			<?php if( !empty( $social_facebook ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Facebook" href="<?php echo esc_url( $social_facebook ); ?>"><i class="fa fa-facebook"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_twitter ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Twitter" href="<?php echo esc_url( $social_twitter ); ?>"><i class="fa fa-twitter"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_googleplus ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Google-plus" href="<?php echo esc_url( $social_googleplus ); ?>"><i class="fa fa-google-plus"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_linkedin ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Linkedin" href="<?php echo esc_url( $social_linkedin ); ?>"><i class="fa fa-linkedin"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_instagram ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Instagram" href="<?php echo esc_url( $social_instagram ); ?>"><i class="fa fa-instagram"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_dribbble ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Dribbble" href="<?php echo esc_url( $social_dribbble ); ?>"><i class="fa fa-dribbble"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_pinterest ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Pinterest" href="<?php echo esc_url( $social_pinterest ); ?>"><i class="fa fa-pinterest"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_apple ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Apple" href="<?php echo esc_url( $social_apple ); ?>"><i class="fa fa-apple"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_tumbler ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Tumbler" href="<?php echo esc_url( $social_tumbler ); ?>"><i class="fa fa-tumblr"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_skype ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Skype" href="<?php echo esc_url( $social_skype ); ?>"><i class="fa fa-skype"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_flickr ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Flickr" href="<?php echo esc_url( $social_flickr ); ?>"><i class="fa fa-flickr"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_youtube_play ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Youtube-play" href="<?php echo esc_url( $social_youtube_play ); ?>"><i class="fa fa-youtube-play"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_dropbox ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Dropbox" href="<?php echo esc_url( $social_dropbox ); ?>"><i class="fa fa-dropbox"></i></a></li><?php endif; ?>
			<?php if( !empty( $social_foursquare ) ): ?><li><a target="_blank" data-toggle="tooltip" data-original-title="Foursquare" href="<?php echo esc_url( $social_foursquare ); ?>"><i class="fa fa-foursquare"></i></a></li><?php endif; ?>
		</ul>

		<?php
		echo html_entity_decode( $args['after_widget'] );
	}

	public function form( $instance ) {

		$instance = wp_parse_args( ( array ) $instance, array( 'title' => '' ) );

		$title = $instance['title'];

		$social_facebook = empty( $instance['social_facebook'] ) ? '' : $instance['social_facebook'];
		$social_twitter = empty( $instance['social_twitter'] ) ? '' : $instance['social_twitter'];
		$social_googleplus = empty( $instance['social_googleplus'] ) ? '' : $instance['social_googleplus'];
		$social_linkedin = empty( $instance['social_linkedin'] ) ? '' : $instance['social_linkedin'];
		$social_instagram = empty( $instance['social_instagram'] ) ? '' : $instance['social_instagram'];
		$social_dribbble = empty( $instance['social_dribbble'] ) ? '' : $instance['social_dribbble'];
		$social_pinterest = empty( $instance['social_pinterest'] ) ? '' : $instance['social_pinterest'];
		$social_apple = empty( $instance['social_apple'] ) ? '' : $instance['social_apple'];
		$social_tumbler = empty( $instance['social_tumbler'] ) ? '' : $instance['social_tumbler'];
		$social_skype = empty( $instance['social_skype'] ) ? '' : $instance['social_skype'];
		$social_flickr = empty( $instance['social_flickr'] ) ? '' : $instance['social_flickr'];
		$social_youtube_play = empty( $instance['social_youtube_play'] ) ? '' : $instance['social_youtube_play'];
		$social_dropbox = empty( $instance['social_dropbox'] ) ? '' : $instance['social_dropbox'];
		$social_foursquare = empty( $instance['social_foursquare'] ) ? '' : $instance['social_foursquare'];
		
	
		
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('title') ); ?>" name="<?php echo esc_html( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_facebook') ); ?>"><?php esc_html_e('Facebook:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_facebook') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_facebook') ); ?>" type="text" value="<?php echo esc_url( $social_facebook ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_twitter') ); ?>"><?php esc_html_e('Twitter:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_twitter') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_twitter') ); ?>" type="text" value="<?php echo esc_url( $social_twitter ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_googleplus') ); ?>"><?php esc_html_e('Google Plus:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_googleplus') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_googleplus') ); ?>" type="text" value="<?php echo esc_url( $social_googleplus ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_linkedin') ); ?>"><?php esc_html_e('Linkedin', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_linkedin') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_linkedin') ); ?>" type="text" value="<?php echo esc_url( $social_linkedin ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_instagram') ); ?>"><?php esc_html_e('Instagram', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_instagram') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_instagram') ); ?>" type="text" value="<?php echo esc_url( $social_instagram ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_dribbble') ); ?>"><?php esc_html_e('Dribbble', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_dribbble') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_dribbble') ); ?>" type="text" value="<?php echo esc_url( $social_dribbble ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_pinterest') ); ?>"><?php esc_html_e('Pinterest', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_pinterest') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_pinterest') ); ?>" type="text" value="<?php echo esc_url( $social_pinterest ); ?>" /></label></p>	
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_apple') ); ?>"><?php esc_html_e('Apple', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_apple') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_apple') ); ?>" type="text" value="<?php echo esc_url( $social_apple ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_tumbler') ); ?>"><?php esc_html_e('Tumblr:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_tumbler') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_tumbler') ); ?>" type="text" value="<?php echo esc_url( $social_tumbler ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_skype') ); ?>"><?php esc_html_e('Skype:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_skype') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_skype') ); ?>" type="text" value="<?php echo esc_url( $social_skype ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_flickr') ); ?>"><?php esc_html_e('Flickr:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_flickr') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_flickr') ); ?>" type="text" value="<?php echo esc_url( $social_flickr ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_youtube_play') ); ?>"><?php esc_html_e('Youtube Play:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_youtube_play') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_youtube_play') ); ?>" type="text" value="<?php echo esc_url( $social_youtube_play ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_dropbox') ); ?>"><?php esc_html_e('Dropbox:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_dropbox') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_dropbox') ); ?>" type="text" value="<?php echo esc_url( $social_dropbox ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('social_foursquare') ); ?>"><?php esc_html_e('Foursquare:', "maxigen-toolkit"); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('social_foursquare') ); ?>" name="<?php echo esc_html( $this->get_field_name('social_foursquare') ); ?>" type="text" value="<?php echo esc_url( $social_foursquare ); ?>" /></label></p>
		
		<?php
	}

	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		$new_instance = wp_parse_args( ( array ) $new_instance, array('title' => '') );

		$instance['title'] = strip_tags( $new_instance['title'] );

		$instance['social_facebook'] = ( ! empty( $new_instance['social_facebook'] ) ) ? strip_tags( $new_instance['social_facebook'] ) : '';
		$instance['social_twitter'] = ( ! empty( $new_instance['social_twitter'] ) ) ? strip_tags( $new_instance['social_twitter'] ) : '';
		$instance['social_googleplus'] = ( ! empty( $new_instance['social_googleplus'] ) ) ? strip_tags( $new_instance['social_googleplus'] ) : '';
		$instance['social_linkedin'] = ( ! empty( $new_instance['social_linkedin'] ) ) ? strip_tags( $new_instance['social_linkedin'] ) : '';
		$instance['social_instagram'] = ( ! empty( $new_instance['social_instagram'] ) ) ? strip_tags( $new_instance['social_instagram'] ) : '';
		$instance['social_dribbble'] = ( ! empty( $new_instance['social_dribbble'] ) ) ? strip_tags( $new_instance['social_dribbble'] ) : '';
		$instance['social_pinterest'] = ( ! empty( $new_instance['social_pinterest'] ) ) ? strip_tags( $new_instance['social_pinterest'] ) : '';
		$instance['social_apple'] = ( ! empty( $new_instance['social_apple'] ) ) ? strip_tags( $new_instance['social_apple'] ) : '';
		$instance['social_tumbler'] = ( ! empty( $new_instance['social_tumbler'] ) ) ? strip_tags( $new_instance['social_tumbler'] ) : '';
		$instance['social_skype'] = ( ! empty( $new_instance['social_skype'] ) ) ? strip_tags( $new_instance['social_skype'] ) : '';
		$instance['social_flickr'] = ( ! empty( $new_instance['social_flickr'] ) ) ? strip_tags( $new_instance['social_flickr'] ) : '';
		$instance['social_youtube_play'] = ( ! empty( $new_instance['social_youtube_play'] ) ) ? strip_tags( $new_instance['social_youtube_play'] ) : '';
		$instance['social_dropbox'] = ( ! empty( $new_instance['social_dropbox'] ) ) ? strip_tags( $new_instance['social_dropbox'] ) : '';
		$instance['social_foursquare'] = ( ! empty( $new_instance['social_foursquare'] ) ) ? strip_tags( $new_instance['social_foursquare'] ) : '';
		
		return $instance;
	}
}