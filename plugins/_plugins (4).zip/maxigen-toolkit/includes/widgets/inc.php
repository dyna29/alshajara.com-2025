<?php

/**
 * Theme setup.
 *
 * Set up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support post thumbnails.
 *
 * @since Maxigen 1.0
 */

if( !function_exists('maxigen_widget_setup') ) :

	function maxigen_widget_setup() {

		/* Script For Widget */
		add_image_size( 'maxigen-59-59', 59, 59, true ); /* Recent Posts Widget */
	}
	add_action( 'after_setup_theme', 'maxigen_widget_setup' );
endif;

/* Widget Register / UN-register */
function maxigen_manage_widgets() {

	/* Recent Posts */
	require_once("recent_posts.php");
	register_widget( 'MAXIGEN_Widget_RecentPosts' );

	/* Contact */
	require_once("social_icons.php");
	register_widget( 'MAXIGEN_Widget_Social' );
	
	/* Twitter */
	require_once("twitter.php");
	register_widget( 'MAXIGEN_Widget_Recent_Tweets' );
	
	/* Image Upload */
	require_once("flicker_photos.php");
	register_widget( 'MAXIGEN_Widget_Flicker_Photos' );
	
}
add_action( 'widgets_init', 'maxigen_manage_widgets' );