<?php
if ( ! function_exists( 'maxigen_to_slug' ) ) :
	function maxigen_to_slug( $string ){
		return strtolower( trim( preg_replace('/[^A-Za-z0-9-]+/', '_', $string) ) );
	}
endif;

/* Custom Excerpt Limit */
if ( ! function_exists( 'maxigen_custom_excerpts' ) ) :
	function maxigen_custom_excerpts( $limit ) {
		$excerpt = explode(' ', get_the_excerpt(), $limit);
		if ( count($excerpt) >= $limit ) :
		
			array_pop($excerpt);
			$excerpt = implode(" ",$excerpt).'...';
		
		else :
		
			$excerpt = implode(" ",$excerpt);
		
		endif; 

		$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
		return $excerpt;
	}
endif;

if ( ! function_exists( 'maxigen_custom_length' ) ) :
	function maxigen_custom_length( $value, $limit ) {
		$excerpt = explode(' ', $value, $limit);
		if ( count($excerpt) >= $limit ) :
		
			array_pop($excerpt);
			$excerpt = implode(" ",$excerpt).'...';
		
		else :
		
			$excerpt = implode(" ",$excerpt);
		
		endif; 

		$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
		return $excerpt;
	}
endif;	

/* Check string for Null or Empty & Print It */
if ( ! function_exists( 'maxigen_content' ) ) :

	function maxigen_content( $before_val, $after_val, $val ) {

		if( $val != "" ) {
			return $before_val.$val.$after_val;
		}
		else {
			return "";
		}
	}
endif;

/* Check array element for Null or Empty */
if ( ! function_exists( 'maxigen_checkarray' ) ) :
	function maxigen_checkarray( $arrOptions, $strKey ) {

		if( is_array( $arrOptions )
			&& array_key_exists( $strKey, $arrOptions ) 
			&& isset( $arrOptions[$strKey] ) 
			&& trim( $arrOptions[$strKey] ) != '' 
		) {
			return true;
		} 
		
		return false;
	}
endif;

/* Check string for Null or Empty */
if ( ! function_exists( 'maxigen_checkstring' ) ) :
	function maxigen_checkstring( $strValue ) {
		if ( isset( $strValue ) && trim( $strValue ) != '' ) :
			return true;
		endif;
		
		return false;
	}
endif;

if( !function_exists('maxigen_options') ) :

	function maxigen_options( $option, $arr = null ) {

		global $maxigen_option;

		if( $arr ) {

			if( isset( $maxigen_option[$option][$arr] ) ) {
				return $maxigen_option[$option][$arr];
			}
		}
		else {
			if( isset( $maxigen_option[$option] ) ) {
				return $maxigen_option[$option];
			}
		}
	}
endif;
?>