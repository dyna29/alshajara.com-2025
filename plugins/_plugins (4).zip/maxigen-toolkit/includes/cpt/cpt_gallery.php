<?php
/* CPT : Gallery*/
if ( ! function_exists('maxigen_cpt_gallery') ) {

	add_action( 'init', 'maxigen_cpt_gallery', 0 );
	function maxigen_cpt_gallery() {

		$labels = array(
			'name' =>  esc_html('Gallery', "maxigen-toolkit"),
			'singular_name' => esc_html('Gallery', "maxigen-toolkit"),
			'add_new' => esc_html('Add New', "maxigen-toolkit"),
			'add_new_item' => esc_html('Add New Gallery', "maxigen-toolkit"),
			'edit_item' => esc_html('Edit Gallery', "maxigen-toolkit"),
			'new_item' => esc_html('New Gallery', "maxigen-toolkit"),
			'all_items' => esc_html('All Gallery', "maxigen-toolkit"),
			'view_item' => esc_html('View Gallery', "maxigen-toolkit"),
			'search_items' => esc_html('Search Gallery', "maxigen-toolkit"),
			'not_found' =>  esc_html('No Gallery found', "maxigen-toolkit"),
			'not_found_in_trash' => esc_html('No Gallery found in Trash', "maxigen-toolkit"),
			'parent_item_colon' => '',
			'menu_name' => esc_html('Gallery', "maxigen-toolkit")
		);

		$args = array(			
			'labels' => $labels,
			'hierarchical' => false,
			'supports' => array( 'title', 'thumbnail' ),
			'rewrite'  => array( 'slug' => 'gallery-item' ),
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'menu_position' => 101,
			'menu_icon' => 'dashicons-portfolio',
			'show_in_nav_menus' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'has_archive' => false,
			'query_var' => true,
			'can_export' => true,
			'rewrite' => true,
			'capability_type' => 'post'
		);
		register_post_type( 'maxigen_gallery', $args );
	}
}