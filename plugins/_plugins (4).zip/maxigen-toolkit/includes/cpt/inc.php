<?php

	/* Include all individual CPT. */
	$prefix_cpt = "cpt_";

	/* Portfolio */
	require_once( $prefix_cpt . "gallery.php" );
?>