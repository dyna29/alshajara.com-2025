﻿=== Instagram Slider===
 
Contributors: nexuslink
Donate link:
Tags: Instagram, Dynamic Instagram Slider, Multiple Instagram Slider, Instagram Slider, Instagram feeds, Instagram grid, Instagram carousel, Widget instagram, Embed instagram, responsive carousel, wordpress carousel, Instagram gallery, Lightbox, Instagram pictures

Requires at least: 3.0.1

Tested up to: 4.7

Version: 3.3

Stable tag: 3.3
License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html


Instagram photos and videos with simple shortcodes and widgets for profiles and hashtags on posts, pages, sidebar.



==  Description==



Instagram pictures and Instagram videos in your website with carousel and grid view!


Publish easily Instagram photos in your pages, posts, sidebars thanks to simple shortcodes and widgets.

Each Instagram photo can be shown in Carousel and Grid mode with Lightbox effect.Instagram Slider is responsive and optimized for mobile devices.


External Services:
We have to call external services for finding access token which will be used to find instagram account images and video for Instagram slider using our Instagram client id and client secrete key.
http://111.93.83.62/put_access_token.php

When you login using your instragram account this url will be called to use client ID and client secret key to find the access token of your instagram account and redirect back with that token to your instagram slider plugin url.

Ordered list:

1. One click to Connect with your Instagram Account
2. Connect multiple account to create multiple Instagram Sliders
3. Very Simple to Use
4. Show pictures of Instagram profiles and/or Hashtags
5. Use Grid or Carousel view
6. Fade In Effect for Grid View
7. Customize the Number of columns and rows
8. Customize the Number of pictures to see in same time
9. Use Navigations buttons (yes/no)
10. Use Shortcodes button in the editor
11. Display Widgets Instagram Feeds on sidebars
12. Create multiple Instagram Slider as may as you wish and use its short code in website.

== Installation ==
1. Upload "Instgram Slider" to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.

== Frequently Asked Questions ==
= What about support? =
Create a support ticket at WordPress forum and I will take care of any issue.

== Screenshots ==
None yet

== Changelog ==
= 1.0 =
* Initial release.