<?php

return [
    'api_key'              => '',
    'debug_log_level'      => 'warning',
];
