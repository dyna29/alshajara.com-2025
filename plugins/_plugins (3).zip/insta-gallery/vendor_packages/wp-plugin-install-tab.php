<?php

if ( class_exists( 'QuadLayers\\WP_Plugin_Install_Tab\\Load' ) ) {
	QuadLayers\WP_Plugin_Install_Tab\Load::instance();
}
