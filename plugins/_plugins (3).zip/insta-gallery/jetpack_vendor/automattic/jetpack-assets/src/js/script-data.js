export * from '@automattic/jetpack-script-data';
