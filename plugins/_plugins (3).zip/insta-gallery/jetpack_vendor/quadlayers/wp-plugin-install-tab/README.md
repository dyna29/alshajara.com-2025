# wp-plugin-install-tab
Create a custom page to display author plugin suggestions with install and activate buttons.
