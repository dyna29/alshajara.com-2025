<?php

namespace QuadLayers\IGG\Gutenberg;

class Load extends \QuadLayers\IGG\Controllers\Gutenberg {

}
