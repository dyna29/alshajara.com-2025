<?php

namespace QuadLayers\IGG\Backend;

class Load extends \QuadLayers\IGG\Controllers\Backend {

}
