<?php

namespace QuadLayers\IGG\Frontend;

class Load extends \QuadLayers\IGG\Controllers\Frontend {

}
