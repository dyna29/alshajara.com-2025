<?php

echo sprintf( '[gslogo id=%d]', $settings->shortcode_id );